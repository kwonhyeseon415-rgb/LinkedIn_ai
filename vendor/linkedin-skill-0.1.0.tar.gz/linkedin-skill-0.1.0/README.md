# LinkedIn Content Skill

## Product Positioning
This repository is the **skill-first LinkedIn content generation backend**.

It is designed to be:
- independently callable
- reusable
- testable
- configurable
- packageable without any web frontend code

The separate Streamlit shell belongs in the sibling repository `linkedin-skill-web`.

## Scope
Current scope remains intentionally narrow:
- LinkedIn only
- pasted text / TXT / PDF input
- planner-orchestrator output for text / image / video generation prompts
- final LinkedIn draft generation from the text executor
- image/video placeholder executors with explicit non-connected status

This repository does **not** ship a web UI and does **not** connect image or video providers yet.

## Deployment Artifact For The Web Shell
When `linkedin-skill-web` needs a self-contained deploy path for Streamlit Community Cloud, build a fresh source distribution from this repo and refresh the vendored package in the web repo:

```bash
python setup.py sdist --dist-dir ../linkedin-skill-web/vendor
```

That keeps the split-repo boundary intact while giving the web shell a concrete package artifact it can install from `requirements.txt`.

## Architecture

### Layering
The backend is organized into:
- `linkedin_skill/interfaces`
- `linkedin_skill/ingestion`
- `linkedin_skill/parsing`
- `linkedin_skill/normalization`
- `linkedin_skill/planner`
- `linkedin_skill/executors`
- `linkedin_skill/pipeline`
- `linkedin_skill/config`
- `linkedin_skill/adapters`
- `tests`

### Primary Runtime Flow
The live path is:
1. `SkillRequest`
2. ingestion
3. parsing
4. normalization
5. planner
6. text executor
7. image executor placeholder
8. video executor placeholder
9. `SkillResponse`

The unified runtime entrypoint is:
- [`linkedin_skill/adapters/python_api.py`](linkedin_skill/adapters/python_api.py)

The core orchestrator is:
- [`linkedin_skill/pipeline/skill_pipeline.py`](linkedin_skill/pipeline/skill_pipeline.py)

## Stability System Additions

This backend now includes the first lightweight pieces of the LinkedIn publish-ready draft system:
- packaged style assets in `linkedin_skill/style_assets`
- structured planner `text_plan`
- structured text executor `draft_variants`
- a text quality checker with at most one rewrite pass

The legacy response fields are still preserved. Consumers can continue reading:
- `final_linkedin_drafts`
- `draft_bundle.final_linkedin_drafts`
- `draft_bundle.chinese_translation`

New structured consumers can also inspect:
- `planner_output.text_plan`
- `text_executor_result.payload["draft_variants"]`
- `text_executor_result.payload["checker_report"]`
- `text_executor_result.payload["rewrite_applied"]`

## Unified Protocol
Formal protocol objects are defined in:
- [`linkedin_skill/interfaces/schemas.py`](linkedin_skill/interfaces/schemas.py)

The public schema set is:
- `SkillRequest`
- `ParsedSource`
- `NormalizedSourcePackage`
- `PlannerOutput`
- `ExecutorResult`
- `SkillResponse`

### Status Vocabulary
The shared status vocabulary is:
- `success`
- `skipped`
- `placeholder_not_connected`
- `failed`
- `partial_success`

This status vocabulary is used across:
- parsing outputs
- normalization outputs
- planner outputs
- executor outputs
- pipeline overall status

### Failure Envelope
The pipeline now attempts to return a `SkillResponse` envelope even when a stage fails.

Examples:
- source processing failure -> `SkillResponse.status == "failed"`
- planner failure -> `PlannerOutput.status == "failed"` and downstream executors are `skipped`
- text executor failure -> `ExecutorResult(status="failed")` while other placeholder executors still return their own stage status

`SkillResponse` also includes:
- `core_status`
- `stage_statuses`
- `capability_gaps`
- `warnings`
- `error_message`

That makes the stage contract reviewable without relying only on exceptions.

## Request / Ingestion
The input request contract lives in:
- [`linkedin_skill/interfaces/schemas.py`](linkedin_skill/interfaces/schemas.py)

Shared request validation is enforced in `SkillRequest`, not only in the web shell.

Source ingestion starts in:
- [`linkedin_skill/ingestion/source_ingestion.py`](linkedin_skill/ingestion/source_ingestion.py)

## Parsing

### Text Inputs
Text parsing lives in:
- [`linkedin_skill/parsing/text_parsers.py`](linkedin_skill/parsing/text_parsers.py)

### PDF Inputs
PDF parsing is split into:
- channel implementation helpers in [`linkedin_skill/parsing/pdf_channels.py`](linkedin_skill/parsing/pdf_channels.py)
- PDF channel orchestration in [`linkedin_skill/parsing/pdf_coordinator.py`](linkedin_skill/parsing/pdf_coordinator.py)

#### Channel A: Local structured parsing / markdown flattening
This channel:
- uses `pypdf` when available
- falls back to local stream extraction when needed
- flattens extracted content into a markdown-like local representation

#### Channel B: LLM document understanding over extracted text
This channel:
- consumes the shared raw extracted PDF text
- uses OpenAI for document understanding
- produces a structured markdown-like understanding view

This is intentionally named as an **understanding channel over extracted text**, not as an independent binary PDF parser.

## Normalization
Normalization is handled in:
- [`linkedin_skill/normalization/source_normalizer.py`](linkedin_skill/normalization/source_normalizer.py)

PDF fusion policy is separated into:
- [`linkedin_skill/normalization/pdf_fusion.py`](linkedin_skill/normalization/pdf_fusion.py)

The planner only consumes:
- `NormalizedSourcePackage`

It does **not** consume raw PDF parsing outputs directly.

### PDF Fusion Rules
- both channels succeed -> `success`
- one channel succeeds and the other is intentionally disabled -> `success` with warning
- one channel succeeds and the other fails unexpectedly -> `partial_success` with warning
- both channels fail -> normalization stage becomes `failed`

### OCR Extension
OCR is still not connected, but the parsing layer now exposes an explicit OCR extension slot. The slot reports `skipped` when OCR is disabled, `placeholder_not_connected` when the slot is enabled without a provider, and does not downgrade the core text path by itself.

## Planner
The planner lives in:
- [`linkedin_skill/planner/orchestrator.py`](linkedin_skill/planner/orchestrator.py)

The planner returns:
- `highlights_summary`
- `text_generation_prompt`
- `image_generation_prompt`
- `video_generation_prompt`
- `status`
- `error_message`

Planner role instructions, model selection, templates, and runtime parameters are configured through:
- [`linkedin_skill/config/settings.py`](linkedin_skill/config/settings.py)

## Executors

### Text Executor
The text executor lives in:
- [`linkedin_skill/executors/text_executor.py`](linkedin_skill/executors/text_executor.py)

It consumes:
- `PlannerOutput.text_generation_prompt`
- `PlannerOutput.text_plan`

It returns:
- `ExecutorResult(status="success" | "failed", ...)`
- structured draft variants in `ExecutorResult.payload["draft_variants"]`
- a legacy flattened draft string in `ExecutorResult.output_text`
- a bilingual draft bundle in `ExecutorResult.payload["draft_bundle"]`

### Text Quality Checker
The checker lives in:
- [`linkedin_skill/checkers/text_quality_checker.py`](linkedin_skill/checkers/text_quality_checker.py)

The pipeline runs the checker after structured draft generation. If the checker marks `rewrite_required=true`, the pipeline performs at most one rewrite and then checks the rewritten draft once more.

Checker failures do not discard successfully generated drafts. They are surfaced through warnings and checker error payload fields.

## Lightweight Regression Fixtures

Regression fixtures are intentionally text-only curated assets. The backend does not automatically archive uploaded PDFs, TXT files, or raw runtime inputs.

Preferred regression fixture format:
- JSONL
- one curated case per line
- normalized source excerpts instead of raw binary files

The seed fixture lives at:
- [`tests/fixtures/linkedin_regression_cases.jsonl`](tests/fixtures/linkedin_regression_cases.jsonl)

The runner entrypoint is:
- `linkedin_skill.pipeline.batch_pipeline.run_linkedin_regression_checks`

Example:

```python
from linkedin_skill.pipeline.batch_pipeline import run_linkedin_regression_checks

report = run_linkedin_regression_checks("tests/fixtures/linkedin_regression_cases.jsonl")
```

The runner treats a case as successful when the skill returns `success` or `partial_success` and the checker report says `publish_ready=True`. It is not an exact-match text comparison system.

### Image Executor Placeholder
The image executor lives in:
- [`linkedin_skill/executors/image_executor.py`](linkedin_skill/executors/image_executor.py)

Current contract:
- returns `status="placeholder_not_connected"`
- returns the planner-generated image prompt as `output_text`
- returns explicit payload fields such as:
  - `provider_connected: false`
  - `artifact_type: "image_generation_prompt"`
  - `execution_mode: "prompt_only"`
  - `placeholder_contract_version`

### Video Executor Placeholder
The video executor lives in:
- [`linkedin_skill/executors/video_executor.py`](linkedin_skill/executors/video_executor.py)

Current contract:
- returns `status="placeholder_not_connected"`
- returns the planner-generated video prompt as `output_text`
- returns explicit payload fields such as:
  - `provider_connected: false`
  - `artifact_type: "video_generation_prompt"`
  - `execution_mode: "prompt_only"`
  - `placeholder_contract_version`

These placeholder executors are intentionally explicit and do not pretend to be connected providers.

## Configuration
Configuration lives in:
- [`linkedin_skill/config/settings.py`](linkedin_skill/config/settings.py)

Current config surface includes:
- models
- role instructions
- prompt templates
- runtime parameters
- feature flags

### Model Overrides Via Environment Variables

The default model config can be overridden without changing code:

```bash
export PLANNER_MODEL="gpt-5.2"
export TEXT_EXECUTOR_MODEL="gpt-5.2"
export PDF_LLM_MODEL="gpt-5.2-mini"
```

If these environment variables are not set, the skill keeps the current built-in defaults.

### Using OpenRouter

The skill keeps official OpenAI as the default path. To route requests through OpenRouter or another OpenAI-compatible proxy, set:

```bash
export OPENAI_API_KEY="sk-or-your-openrouter-key"
export OPENAI_BASE_URL="https://openrouter.ai/api/v1"
export PLANNER_MODEL="openai/gpt-5.2"
export TEXT_EXECUTOR_MODEL="openai/gpt-5.2"
export PDF_LLM_MODEL="openai/gpt-5.2-mini"
```

Optional request headers for OpenRouter:

```bash
export OPENAI_HTTP_REFERER="https://your-app.example"
export OPENAI_APP_TITLE="LinkedIn Skill Demo"
```

Important: when `OPENAI_BASE_URL` points to OpenRouter, model names must use the `provider/model` format such as `openai/gpt-5.2`, not a bare name like `gpt-5.2`.
- content type defaults
- platform defaults

Planner and text executor remain separate role abstractions even if they use the same underlying model provider.

## Adapters

### Python Function Call
Use:
- [`linkedin_skill/adapters/python_api.py`](linkedin_skill/adapters/python_api.py)

Main entrypoint:
- `run_linkedin_skill(request: SkillRequest, config=None)`

### CLI Call
Use:
- [`skill_cli.py`](skill_cli.py)
- [`linkedin_skill/adapters/cli.py`](linkedin_skill/adapters/cli.py)

`skill_cli.py` is the repo-root CLI wrapper and delegates directly to `linkedin_skill.adapters.cli.main`.

Example:
```bash
python skill_cli.py \
  --title "Conference Update" \
  --content-type event_update \
  --target-audience "global biotech partners" \
  --tone professional \
  --post-count 2 \
  --language English \
  --source-kind pasted_text \
  --pasted-text "We presented our latest platform at the conference..."
```

The CLI also supports config overrides for:
- planner / text executor / PDF LLM models
- planner / text executor / PDF-understanding role instructions
- planner / PDF source truncation parameters
- PDF channel feature flags

### Packaging
Install the skill locally:

```bash
python -m pip install -r requirements.txt
python setup.py develop
```

The package exposes:
- the Python entrypoint `run_linkedin_skill(...)`
- the CLI command `linkedin-skill`
- the repo-root wrapper [`skill_cli.py`](skill_cli.py)

## OpenAI Requirement
The following components are API-backed:
- planner
- PDF LLM understanding channel
- text executor

Set:
```bash
export OPENAI_API_KEY="your_api_key_here"
```

Install dependencies:
```bash
python -m pip install -r requirements.txt
```

## Repository Boundary
The active product surface is now limited to:

- the unified skill package in [`linkedin_skill/`](linkedin_skill)
- the repo-root CLI wrapper in [`skill_cli.py`](skill_cli.py)
- the acceptance tests in [`tests/`](tests)

The Streamlit shell is intentionally out of scope for this repository boundary.

## Testing
Tests currently live in:
- [`tests/test_pipeline_smoke.py`](tests/test_pipeline_smoke.py)
- [`tests/test_schema_validation.py`](tests/test_schema_validation.py)
- [`tests/test_cli_smoke.py`](tests/test_cli_smoke.py)
- [`tests/test_openai_compatibility.py`](tests/test_openai_compatibility.py)

Current acceptance-oriented coverage includes:
- pasted text smoke
- TXT smoke
- PDF smoke
- PDF `partial_success` degradation
- PDF success when one channel is disabled by config
- PDF both-channels-failed envelope
- planner failure envelope
- text executor failure envelope
- batch pipeline smoke
- batch `Partial Success` preservation
- CLI smoke
- repo-root `skill_cli.py` wrapper smoke
- placeholder contract assertions
- schema validation for `SkillRequest`, `NormalizedSourcePackage`, `PlannerOutput`, `ExecutorResult`, and `SkillResponse`

Run:
```bash
python -m unittest discover -s tests -p "test*.py"
```

## What Is Executable Now
- pasted text / TXT / PDF ingestion
- normalization
- planner output generation
- final LinkedIn draft generation
- batch checks through the unified skill path
- Python API entrypoint
- CLI entrypoint

## What Is Still Placeholder
- image provider execution
- video provider execution
- OCR for scanned PDFs
