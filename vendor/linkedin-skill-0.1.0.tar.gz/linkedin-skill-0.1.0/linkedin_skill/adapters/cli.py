import argparse
import json

from linkedin_skill.adapters.python_api import run_linkedin_skill
from linkedin_skill.config import get_default_config
from linkedin_skill.interfaces.schemas import SkillRequest


def build_parser():
    parser = argparse.ArgumentParser(description="LinkedIn content generation skill CLI")
    parser.add_argument("--title", required=True)
    parser.add_argument("--content-type", required=True, choices=["paper", "news", "case_study", "event_update"])
    parser.add_argument("--target-audience", required=True)
    parser.add_argument("--tone", required=True)
    parser.add_argument("--post-count", required=True, type=int)
    parser.add_argument("--language", required=True)
    parser.add_argument("--source-kind", required=True, choices=["pasted_text", "txt", "pdf"])
    parser.add_argument("--pasted-text")
    parser.add_argument("--source-path")
    parser.add_argument("--planner-model")
    parser.add_argument("--text-executor-model")
    parser.add_argument("--pdf-llm-model")
    parser.add_argument("--planner-role")
    parser.add_argument("--text-executor-role")
    parser.add_argument("--pdf-understanding-role")
    parser.add_argument("--planner-source-char-limit", type=int)
    parser.add_argument("--pdf-llm-source-char-limit", type=int)
    parser.add_argument("--disable-pdf-llm-channel", action="store_true")
    parser.add_argument("--disable-pdf-local-channel", action="store_true")
    parser.add_argument("--enable-ocr-extension", action="store_true")
    return parser


def build_config_from_args(args):
    config = get_default_config()
    if args.planner_model:
        config.models.planner_model = args.planner_model
    if args.text_executor_model:
        config.models.text_executor_model = args.text_executor_model
    if args.pdf_llm_model:
        config.models.pdf_llm_model = args.pdf_llm_model
    if args.planner_role:
        config.roles.planner_role = args.planner_role
    if args.text_executor_role:
        config.roles.text_executor_role = args.text_executor_role
    if args.pdf_understanding_role:
        config.roles.pdf_understanding_role = args.pdf_understanding_role
    if args.planner_source_char_limit:
        config.runtime_parameters.planner_source_char_limit = max(1, args.planner_source_char_limit)
    if args.pdf_llm_source_char_limit:
        config.runtime_parameters.pdf_llm_source_char_limit = max(1, args.pdf_llm_source_char_limit)
    if args.disable_pdf_llm_channel:
        config.feature_flags.enable_pdf_llm_channel = False
    if args.disable_pdf_local_channel:
        config.feature_flags.enable_pdf_local_channel = False
    if args.enable_ocr_extension:
        config.feature_flags.enable_ocr_extension = True
    return config


def main():
    args = build_parser().parse_args()
    config = build_config_from_args(args)
    request = SkillRequest(
        title=args.title,
        content_type=args.content_type,
        target_audience=args.target_audience,
        tone=args.tone,
        post_count=args.post_count,
        language=args.language,
        source_kind=args.source_kind,
        pasted_text=args.pasted_text,
        source_path=args.source_path,
    )
    response = run_linkedin_skill(request, config)
    print(json.dumps(response.to_dict(), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
