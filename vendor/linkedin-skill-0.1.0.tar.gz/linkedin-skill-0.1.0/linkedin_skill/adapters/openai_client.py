import json
import os
import re

try:
    from openai import APIConnectionError, APIStatusError, AuthenticationError, OpenAI, RateLimitError
except ImportError:  # pragma: no cover - exercised via runtime environments without the SDK
    class APIConnectionError(Exception):
        pass

    class APIStatusError(Exception):
        status_code = None

    class AuthenticationError(Exception):
        pass

    class RateLimitError(Exception):
        pass

    OpenAI = None


class OpenAIPipelineError(Exception):
    pass


class MissingOpenAIAPIKeyError(OpenAIPipelineError):
    pass


class OpenAIAuthenticationFailureError(OpenAIPipelineError):
    pass


class OpenAIQuotaError(OpenAIPipelineError):
    pass


class OpenAIRequestError(OpenAIPipelineError):
    pass


def _get_env_value(name: str) -> str:
    return os.getenv(name, "").strip()


def _get_configured_base_url() -> str:
    return _get_env_value("OPENAI_BASE_URL")


def _build_default_headers():
    default_headers = {}
    http_referer = _get_env_value("OPENAI_HTTP_REFERER")
    app_title = _get_env_value("OPENAI_APP_TITLE")
    if http_referer:
        default_headers["HTTP-Referer"] = http_referer
    if app_title:
        default_headers["X-OpenRouter-Title"] = app_title
    return default_headers


def _uses_non_official_base_url() -> bool:
    base_url = _get_configured_base_url()
    if not base_url:
        return False
    return base_url.rstrip("/") != "https://api.openai.com/v1"


def _validate_model_for_base_url(model: str):
    if not _uses_non_official_base_url():
        return
    if "/" in (model or ""):
        return
    raise OpenAIRequestError(
        "当前已配置非官方 `OPENAI_BASE_URL`，但模型名仍是裸名。"
        "像 OpenRouter 这类 OpenAI-compatible 中转通常要求使用 `provider/model` 形式，"
        "例如 `openai/gpt-5.2`。"
    )


def _build_client():
    if OpenAI is None:
        raise OpenAIRequestError(
            "当前环境未安装 openai SDK。请先执行 `python -m pip install -r requirements.txt`。"
        )
    api_key = _get_env_value("OPENAI_API_KEY")
    if not api_key:
        raise MissingOpenAIAPIKeyError(
            "未检测到 OPENAI_API_KEY。请先在终端中设置环境变量，例如：export OPENAI_API_KEY='your_key'。"
        )
    client_options = {"api_key": api_key}
    base_url = _get_configured_base_url()
    if base_url:
        client_options["base_url"] = base_url
    default_headers = _build_default_headers()
    if default_headers:
        client_options["default_headers"] = default_headers
    return OpenAI(**client_options)


def run_text_response(prompt: str, model: str) -> str:
    try:
        _validate_model_for_base_url(model)
        client = _build_client()
        response = client.responses.create(
            model=model,
            input=prompt,
        )
        output_text = (response.output_text or "").strip()
        if not output_text:
            raise OpenAIRequestError("OpenAI API 返回了空结果，请稍后重试。")
        return output_text
    except MissingOpenAIAPIKeyError:
        raise
    except AuthenticationError as exc:
        raise OpenAIAuthenticationFailureError(
            "API key 无效，或当前账户无权访问所选模型。请检查 OPENAI_API_KEY 与模型配置。"
        ) from exc
    except RateLimitError as exc:
        raise OpenAIQuotaError(
            "模型服务 API 请求被限流，或账户额度 / billing 不足。请检查配额后再试。"
        ) from exc
    except APIConnectionError as exc:
        raise OpenAIRequestError("无法连接到模型服务 API。请检查网络连接后重试。") from exc
    except APIStatusError as exc:
        if exc.status_code == 401:
            raise OpenAIAuthenticationFailureError(
                "API key 无效，认证失败。请检查 OPENAI_API_KEY 与模型配置。"
            ) from exc
        if exc.status_code == 429:
            raise OpenAIQuotaError(
                "模型服务 API 返回 429。可能是请求过快，或账户额度 / billing 不足。"
            ) from exc
        raise OpenAIRequestError(
            f"模型服务 API 请求失败（HTTP {exc.status_code}）。请稍后重试。"
        ) from exc
    except OpenAIPipelineError:
        raise
    except Exception as exc:
        raise OpenAIRequestError(f"调用模型服务 API 时发生未知错误：{exc}") from exc


def run_planner_response(prompt: str, model: str) -> str:
    return run_text_response(prompt, model=model)


def run_text_executor_response(prompt: str, model: str) -> str:
    return run_text_response(prompt, model=model)


def run_pdf_understanding_response(prompt: str, model: str) -> str:
    return run_text_response(prompt, model=model)


def extract_json_payload(raw_text: str, required_fields):
    cleaned = (raw_text or "").strip()
    if not cleaned:
        raise OpenAIRequestError("OpenAI API 返回了空 JSON 结果，请稍后重试。")

    fenced_match = re.search(r"```(?:json)?\s*(\{.*\})\s*```", cleaned, re.DOTALL)
    if fenced_match:
        cleaned = fenced_match.group(1).strip()

    try:
        payload = json.loads(cleaned)
    except json.JSONDecodeError as exc:
        raise OpenAIRequestError("OpenAI 返回的结果不是合法 JSON。") from exc

    missing_fields = [field for field in required_fields if not payload.get(field)]
    if missing_fields:
        raise OpenAIRequestError(
            f"OpenAI 返回的 JSON 缺少字段：{', '.join(missing_fields)}"
        )
    return payload
