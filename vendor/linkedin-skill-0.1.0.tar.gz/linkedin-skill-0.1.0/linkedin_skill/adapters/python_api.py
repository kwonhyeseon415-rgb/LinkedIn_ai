from linkedin_skill.config import get_default_config
from linkedin_skill.interfaces.schemas import SkillRequest
from linkedin_skill.pipeline.skill_pipeline import run_skill_pipeline


def run_linkedin_skill(request: SkillRequest, config=None):
    resolved_config = config or get_default_config()
    return run_skill_pipeline(request, resolved_config)
