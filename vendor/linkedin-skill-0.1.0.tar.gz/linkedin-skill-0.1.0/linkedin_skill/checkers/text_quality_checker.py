import json

from linkedin_skill.adapters.openai_client import extract_json_payload, run_text_response


CHECKER_REQUIRED_FIELDS = (
    "publish_ready",
    "overall_score",
    "style_adherence_score",
    "claim_safety_score",
    "clarity_score",
    "linkedin_fit_score",
    "violations",
    "recommended_fixes",
    "rewrite_required",
)


def _validate_score(value, field_name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"checker_report.{field_name} must be a number")
    return value


def _validate_string_list(value, field_name):
    if not isinstance(value, list):
        raise ValueError(f"checker_report.{field_name} must be a list")
    return [str(item).strip() for item in value if str(item).strip()]


def _validate_checker_report(payload):
    missing = [field for field in CHECKER_REQUIRED_FIELDS if field not in payload]
    if missing:
        raise ValueError(f"checker_report missing fields: {', '.join(missing)}")

    if not isinstance(payload["publish_ready"], bool):
        raise ValueError("checker_report.publish_ready must be a boolean")
    if not isinstance(payload["rewrite_required"], bool):
        raise ValueError("checker_report.rewrite_required must be a boolean")

    return {
        "publish_ready": payload["publish_ready"],
        "overall_score": _validate_score(payload["overall_score"], "overall_score"),
        "style_adherence_score": _validate_score(payload["style_adherence_score"], "style_adherence_score"),
        "claim_safety_score": _validate_score(payload["claim_safety_score"], "claim_safety_score"),
        "clarity_score": _validate_score(payload["clarity_score"], "clarity_score"),
        "linkedin_fit_score": _validate_score(payload["linkedin_fit_score"], "linkedin_fit_score"),
        "violations": _validate_string_list(payload["violations"], "violations"),
        "recommended_fixes": _validate_string_list(payload["recommended_fixes"], "recommended_fixes"),
        "rewrite_required": payload["rewrite_required"],
    }


def run_text_quality_checker(
    *,
    draft_variants,
    text_plan,
    style_profile,
    model,
    checker_prompt_template,
):
    prompt = checker_prompt_template.format(
        draft_variants=json.dumps(draft_variants, ensure_ascii=False, indent=2),
        text_plan=json.dumps(text_plan or {}, ensure_ascii=False, indent=2),
        style_profile=json.dumps(style_profile or {}, ensure_ascii=False, indent=2),
    )
    raw_text = run_text_response(prompt, model=model)
    payload = extract_json_payload(raw_text, required_fields=[])
    return _validate_checker_report(payload)
