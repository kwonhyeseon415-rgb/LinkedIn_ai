from linkedin_skill.config.settings import SkillConfig, get_default_config

__all__ = ["SkillConfig", "get_default_config"]
