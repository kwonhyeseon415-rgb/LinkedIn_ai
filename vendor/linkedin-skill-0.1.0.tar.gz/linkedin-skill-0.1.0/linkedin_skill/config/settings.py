import os
from dataclasses import dataclass, field
from typing import Optional


DEFAULT_CONTENT_TYPE = "paper"
DEMO_PLATFORM = "LinkedIn"
CONTENT_TYPE_OPTIONS = ["paper", "news", "case_study", "event_update"]
CONTENT_TYPE_LABELS = {
    "paper": "论文解读",
    "news": "新闻动态",
    "case_study": "案例拆解",
    "event_update": "活动更新",
}


def _get_model_env_override(env_key: str, default_value: str) -> str:
    return os.getenv(env_key, "").strip() or default_value


def _get_bool_env_override(env_key: str, default_value: bool = False) -> bool:
    value = os.getenv(env_key, "").strip().lower()
    if not value:
        return default_value
    return value in {"1", "true", "yes", "on"}


def _get_runtime_env_override(env_key: str, default_value: str) -> str:
    return os.getenv(env_key, "").strip() or default_value


def _get_style_profile_path_override() -> Optional[str]:
    return os.getenv("STYLE_PROFILE_PATH", "").strip() or None


@dataclass
class OpenAIModelConfig:
    planner_model: str = field(default_factory=lambda: _get_model_env_override("PLANNER_MODEL", "gpt-5.2"))
    text_executor_model: str = field(
        default_factory=lambda: _get_model_env_override("TEXT_EXECUTOR_MODEL", "gpt-5.2")
    )
    pdf_llm_model: str = field(
        default_factory=lambda: _get_model_env_override("PDF_LLM_MODEL", "gpt-5.2-mini")
    )
    image_generator_model: str = field(
        default_factory=lambda: _get_model_env_override("IMAGE_GENERATOR_MODEL", "gpt-image-1")
    )


@dataclass
class RoleInstructionConfig:
    pdf_understanding_role: str = "You are the PDF document understanding channel for a LinkedIn content generation skill."
    planner_role: str = "You are the planner / orchestrator for a LinkedIn content generation skill."
    text_executor_role: str = "You are the text executor for a LinkedIn content generation skill."


@dataclass
class RuntimeParameterConfig:
    pdf_llm_source_char_limit: int = 14000
    planner_source_char_limit: int = 16000
    image_generation_size: str = field(
        default_factory=lambda: _get_runtime_env_override("IMAGE_GENERATION_SIZE", "1024x1024")
    )


@dataclass
class StyleAssetConfig:
    default_style_profile_path: Optional[str] = field(default_factory=_get_style_profile_path_override)


@dataclass
class PromptTemplateConfig:
    pdf_understanding_template: str = (
        "{role_instruction}\n\n"
        "Read the extracted PDF text and return ONLY valid JSON with these fields:\n"
        "{{\n"
        '  "document_summary": "...",\n'
        '  "key_points": ["..."],\n'
        '  "structured_markdown": "..."\n'
        "}}\n\n"
        "Rules:\n"
        "- Stay grounded in the extracted PDF text.\n"
        "- Do not invent unsupported claims.\n"
        "- Keep the summary useful for downstream normalization and planning.\n"
        "- The structured_markdown should flatten the source into a concise, readable markdown-like form.\n"
        "- The output language should be {language}.\n\n"
        "Title: {title}\n"
        "Content type: {content_type}\n"
        "Audience: {target_audience}\n"
        "Tone: {tone}\n\n"
        "Extracted PDF text:\n"
        '"""{source_text}"""'
    )
    planner_template: str = (
        "{role_instruction}\n\n"
        "Read the normalized source package and return ONLY valid JSON with these fields:\n"
        "{{\n"
        '  "highlights_summary": "...",\n'
        '  "text_generation_prompt": "...",\n'
        '  "text_plan": {{\n'
        '    "primary_angle": "...",\n'
        '    "target_reader_takeaway": "...",\n'
        '    "must_include_points": ["..."],\n'
        '    "tone_instructions": ["..."],\n'
        '    "cta_mode": "...",\n'
        '    "length_target": "...",\n'
        '    "style_profile_name": "..."\n'
        "  }},\n"
        '  "image_generation_prompt": "...",\n'
        '  "video_generation_prompt": "..."\n'
        "}}\n\n"
        "Rules:\n"
        "- Ground everything in the normalized source package.\n"
        "- Do not invent unsupported claims.\n"
        "- The text_plan is the structured editorial contract for downstream text execution.\n"
        "- The text_generation_prompt must instruct a downstream text executor to generate exactly {post_count} final LinkedIn drafts.\n"
        "- The text_plan.tone_instructions and text_generation_prompt must reflect the requested tone / style direction when provided.\n"
        "- The image_generation_prompt should be usable by a future image executor.\n"
        "- The video_generation_prompt should be usable by a future video executor.\n"
        "- The output language is {language}.\n"
        "- The platform is LinkedIn only.\n\n"
        "Request context:\n"
        "Title: {title}\n"
        "Content type: {content_type}\n"
        "Audience: {target_audience}\n"
        "Tone / style direction: {tone}\n"
        "Requested post count: {post_count}\n"
        "Output language: {language}\n\n"
        "Style profile JSON:\n"
        "{style_profile_json}\n\n"
        "Normalized source package:\n"
        '"""{normalized_text}"""'
    )
    text_executor_template: str = (
        "{role_instruction}\n\n"
        "Follow the supplied text generation prompt exactly and return ONLY valid JSON with this shape:\n"
        "{{\n"
        '  "draft_variants": [\n'
        "    {{\n"
        '      "variant_id": "...",\n'
        '      "angle": "...",\n'
        '      "hook": "...",\n'
        '      "body": "...",\n'
        '      "cta": "...",\n'
        '      "hashtags": ["#..."],\n'
        '      "full_text": "...",\n'
        '      "risk_flags": ["..."]\n'
        "    }}\n"
        "  ]\n"
        "}}\n\n"
        "Rules:\n"
        "- Return exactly the number of variants requested by the text generation prompt.\n"
        "- Keep every variant grounded in the source-backed plan.\n"
        "- The full_text field must be publication-ready LinkedIn copy.\n"
        "- The hashtags and risk_flags fields must always be arrays.\n"
        "- Return JSON only, with no markdown fences or extra commentary.\n\n"
        "Structured text plan JSON:\n"
        "{text_plan_json}\n\n"
        "Text generation prompt:\n"
        '"""{text_generation_prompt}"""'
    )
    checker_template: str = (
        "Return ONLY valid JSON assessing these LinkedIn draft variants.\n"
        "Use the style profile and text plan as the quality standard.\n\n"
        "Required JSON fields:\n"
        "{{\n"
        '  "publish_ready": true,\n'
        '  "overall_score": 0,\n'
        '  "style_adherence_score": 0,\n'
        '  "claim_safety_score": 0,\n'
        '  "clarity_score": 0,\n'
        '  "linkedin_fit_score": 0,\n'
        '  "violations": ["..."],\n'
        '  "recommended_fixes": ["..."],\n'
        '  "rewrite_required": false\n'
        "}}\n\n"
        "Rules:\n"
        "- Set rewrite_required=true only when the drafts need material correction before use.\n"
        "- Check for unsupported claims, hype, hard-selling CTAs, unclear structure, and style drift.\n"
        "- Return JSON only, with no markdown fences or extra commentary.\n\n"
        "Style profile JSON:\n"
        "{style_profile}\n\n"
        "Structured text plan JSON:\n"
        "{text_plan}\n\n"
        "Draft variants JSON:\n"
        "{draft_variants}"
    )
    rewrite_template: str = (
        "Rewrite these LinkedIn draft variants to resolve the checker findings while staying grounded.\n"
        "Return ONLY valid JSON with the same `draft_variants` shape.\n\n"
        "Rules:\n"
        "- Preserve source-backed meaning and avoid unsupported claims.\n"
        "- Address the checker report directly.\n"
        "- Keep hashtags and risk_flags as arrays.\n"
        "- Return JSON only, with no markdown fences or extra commentary.\n\n"
        "Checker report JSON:\n"
        "{checker_report}\n\n"
        "Structured text plan JSON:\n"
        "{text_plan}\n\n"
        "Current draft variants JSON:\n"
        "{draft_variants}"
    )


@dataclass
class FeatureFlagConfig:
    enable_pdf_llm_channel: bool = True
    enable_pdf_local_channel: bool = True
    enable_ocr_extension: bool = False
    enable_image_generation: bool = field(
        default_factory=lambda: _get_bool_env_override("ENABLE_IMAGE_GENERATION", False)
    )


@dataclass
class SkillConfig:
    platform: str = DEMO_PLATFORM
    default_content_type: str = DEFAULT_CONTENT_TYPE
    content_type_options: list = field(default_factory=lambda: list(CONTENT_TYPE_OPTIONS))
    content_type_labels: dict = field(default_factory=lambda: dict(CONTENT_TYPE_LABELS))
    style_assets: StyleAssetConfig = field(default_factory=StyleAssetConfig)
    models: OpenAIModelConfig = field(default_factory=OpenAIModelConfig)
    roles: RoleInstructionConfig = field(default_factory=RoleInstructionConfig)
    runtime_parameters: RuntimeParameterConfig = field(default_factory=RuntimeParameterConfig)
    prompt_templates: PromptTemplateConfig = field(default_factory=PromptTemplateConfig)
    feature_flags: FeatureFlagConfig = field(default_factory=FeatureFlagConfig)


def get_default_config() -> SkillConfig:
    return SkillConfig()
