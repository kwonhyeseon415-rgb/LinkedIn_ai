from dataclasses import dataclass, field


DEFAULT_CONTENT_TYPE = "paper"
DEMO_PLATFORM = "LinkedIn"
CONTENT_TYPE_OPTIONS = ["paper", "news", "case_study", "event_update"]
CONTENT_TYPE_LABELS = {
    "paper": "论文解读",
    "news": "新闻动态",
    "case_study": "案例拆解",
    "event_update": "活动更新",
}


@dataclass
class OpenAIModelConfig:
    planner_model: str = "gpt-5.2"
    text_executor_model: str = "gpt-5.2"
    pdf_llm_model: str = "gpt-5.2-mini"


@dataclass
class RoleInstructionConfig:
    pdf_understanding_role: str = "You are the PDF document understanding channel for a LinkedIn content generation skill."
    planner_role: str = "You are the planner / orchestrator for a LinkedIn content generation skill."
    text_executor_role: str = "You are the text executor for a LinkedIn content generation skill."


@dataclass
class RuntimeParameterConfig:
    pdf_llm_source_char_limit: int = 14000
    planner_source_char_limit: int = 16000


@dataclass
class PromptTemplateConfig:
    pdf_understanding_template: str = (
        "{role_instruction}\n\n"
        "Read the extracted PDF text and return ONLY valid JSON with these fields:\n"
        "{{\n"
        '  "document_summary": "...",\n'
        '  "key_points": ["..."],\n'
        '  "structured_markdown": "..."\n'
        "}}\n\n"
        "Rules:\n"
        "- Stay grounded in the extracted PDF text.\n"
        "- Do not invent unsupported claims.\n"
        "- Keep the summary useful for downstream normalization and planning.\n"
        "- The structured_markdown should flatten the source into a concise, readable markdown-like form.\n"
        "- The output language should be {language}.\n\n"
        "Title: {title}\n"
        "Content type: {content_type}\n"
        "Audience: {target_audience}\n"
        "Tone: {tone}\n\n"
        "Extracted PDF text:\n"
        '"""{source_text}"""'
    )
    planner_template: str = (
        "{role_instruction}\n\n"
        "Read the normalized source package and return ONLY valid JSON with these fields:\n"
        "{{\n"
        '  "highlights_summary": "...",\n'
        '  "text_generation_prompt": "...",\n'
        '  "image_generation_prompt": "...",\n'
        '  "video_generation_prompt": "..."\n'
        "}}\n\n"
        "Rules:\n"
        "- Ground everything in the normalized source package.\n"
        "- Do not invent unsupported claims.\n"
        "- The text_generation_prompt must instruct a downstream text executor to generate exactly {post_count} final LinkedIn drafts.\n"
        "- The image_generation_prompt should be usable by a future image executor.\n"
        "- The video_generation_prompt should be usable by a future video executor.\n"
        "- The output language is {language}.\n"
        "- The platform is LinkedIn only.\n\n"
        "Normalized source package:\n"
        '"""{normalized_text}"""'
    )
    text_executor_template: str = (
        "{role_instruction}\n\n"
        "Follow the supplied text generation prompt exactly and return final publication-ready LinkedIn drafts.\n\n"
        "Text generation prompt:\n"
        '"""{text_generation_prompt}"""'
    )


@dataclass
class FeatureFlagConfig:
    enable_pdf_llm_channel: bool = True
    enable_pdf_local_channel: bool = True
    enable_ocr_extension: bool = False


@dataclass
class SkillConfig:
    platform: str = DEMO_PLATFORM
    default_content_type: str = DEFAULT_CONTENT_TYPE
    content_type_options: list = field(default_factory=lambda: list(CONTENT_TYPE_OPTIONS))
    content_type_labels: dict = field(default_factory=lambda: dict(CONTENT_TYPE_LABELS))
    models: OpenAIModelConfig = field(default_factory=OpenAIModelConfig)
    roles: RoleInstructionConfig = field(default_factory=RoleInstructionConfig)
    runtime_parameters: RuntimeParameterConfig = field(default_factory=RuntimeParameterConfig)
    prompt_templates: PromptTemplateConfig = field(default_factory=PromptTemplateConfig)
    feature_flags: FeatureFlagConfig = field(default_factory=FeatureFlagConfig)


def get_default_config() -> SkillConfig:
    return SkillConfig()
