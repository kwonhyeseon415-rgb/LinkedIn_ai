from linkedin_skill.interfaces.schemas import ExecutorResult, PlannerOutput


def run_image_executor(planner_output: PlannerOutput, config) -> ExecutorResult:
    return ExecutorResult(
        executor_name="image_executor",
        status="placeholder_not_connected",
        output_text=planner_output.image_generation_prompt,
        payload={
            "model": None,
            "provider_connected": False,
            "placeholder_contract_version": "1.0",
            "artifact_type": "image_generation_prompt",
            "execution_mode": "prompt_only",
            "note": "Image API is not connected in this iteration.",
        },
        warnings=["Image executor is intentionally a placeholder and does not call an external API yet."],
    )
