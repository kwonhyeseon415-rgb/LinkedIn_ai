from linkedin_skill.adapters.openai_client import run_image_generation
from linkedin_skill.interfaces.schemas import ExecutorResult, PlannerOutput


def _build_prompt_only_result(planner_output: PlannerOutput) -> ExecutorResult:
    return ExecutorResult(
        executor_name="image_executor",
        status="placeholder_not_connected",
        output_text=planner_output.image_generation_prompt,
        payload={
            "model": None,
            "provider_connected": False,
            "placeholder_contract_version": "1.0",
            "artifact_type": "image_generation_prompt",
            "execution_mode": "prompt_only",
            "note": "Image API is not connected in this iteration.",
        },
        warnings=["Image executor is intentionally a placeholder and does not call an external API yet."],
    )


def _build_generated_image_output(image_prompt: str, image_payload: dict) -> str:
    sections = ["Image prompt", image_prompt]
    if image_payload.get("image_url"):
        sections.extend(["Generated image URL", image_payload["image_url"]])
    if image_payload.get("image_base64"):
        sections.extend(["Generated image", "Base64 image content is available in the structured payload and rendered by the web app."])
    if image_payload.get("revised_prompt"):
        sections.extend(["Revised prompt", image_payload["revised_prompt"]])
    return "\n\n".join(sections).strip()


def run_image_executor(planner_output: PlannerOutput, config) -> ExecutorResult:
    if not config.feature_flags.enable_image_generation:
        return _build_prompt_only_result(planner_output)

    image_prompt = planner_output.image_generation_prompt.strip()
    image_payload = run_image_generation(
        image_prompt,
        model=config.models.image_generator_model,
        size=config.runtime_parameters.image_generation_size,
    )

    return ExecutorResult(
        executor_name="image_executor",
        status="success",
        output_text=_build_generated_image_output(image_prompt, image_payload),
        payload={
            "model": config.models.image_generator_model,
            "provider_connected": True,
            "artifact_type": "generated_image",
            "execution_mode": "image_generation",
            "image_prompt": image_prompt,
            "image_url": image_payload.get("image_url", ""),
            "image_base64": image_payload.get("image_base64", ""),
            "revised_prompt": image_payload.get("revised_prompt", ""),
            "mime_type": "image/png",
            "size": config.runtime_parameters.image_generation_size,
        },
    )
