import json

from linkedin_skill.adapters.openai_client import extract_json_payload, run_text_executor_response
from linkedin_skill.interfaces.schemas import ExecutorResult, PlannerOutput


def _build_chinese_translation_prompt(english_drafts: str) -> str:
    return (
        "Translate the following LinkedIn drafts into clear, natural Simplified Chinese.\n\n"
        "Rules:\n"
        "- Preserve the original structure, paragraph breaks, separators, bullets, numbering, emojis, hashtags, and calls to action.\n"
        "- Keep the meaning aligned with the English source.\n"
        "- Do not add commentary, explanations, or extra content.\n"
        "- Return only the Chinese translation.\n\n"
        "English LinkedIn drafts:\n"
        f'"""{english_drafts}"""'
    )


REQUIRED_VARIANT_FIELDS = (
    "variant_id",
    "angle",
    "hook",
    "body",
    "cta",
    "full_text",
)


def _validate_string_field(variant, field_name: str, index: int) -> str:
    value = variant.get(field_name)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"draft_variants[{index}].{field_name} must be a non-empty string")
    return value.strip()


def _validate_string_list_field(variant, field_name: str, index: int):
    if field_name not in variant or variant.get(field_name) is None:
        raise ValueError(f"draft_variants[{index}].{field_name} must be a list")
    value = variant.get(field_name)
    if not isinstance(value, list):
        raise ValueError(f"draft_variants[{index}].{field_name} must be a list when provided")
    normalized_items = []
    for item in value:
        if not isinstance(item, str):
            raise ValueError(f"draft_variants[{index}].{field_name} items must be strings")
        cleaned = item.strip()
        if cleaned:
            normalized_items.append(cleaned)
    return normalized_items


def _normalize_variant_list(raw_variants):
    if not isinstance(raw_variants, list) or not raw_variants:
        raise ValueError("draft_variants must be a non-empty list")

    variants = []
    for index, item in enumerate(raw_variants, start=1):
        if not isinstance(item, dict):
            raise ValueError(f"draft_variants[{index}] must be an object")
        variant = dict(item)
        variants.append(
            {
                field_name: _validate_string_field(variant, field_name, index)
                for field_name in REQUIRED_VARIANT_FIELDS
            }
        )
        variants[-1]["hashtags"] = _validate_string_list_field(variant, "hashtags", index)
        variants[-1]["risk_flags"] = _validate_string_list_field(variant, "risk_flags", index)
    return variants


def _flatten_variant_text(variants) -> str:
    return "\n\n---\n\n".join(
        variant["full_text"]
        for variant in variants
        if variant.get("full_text")
    )


def _build_text_executor_prompt(planner_output: PlannerOutput, config) -> str:
    return config.prompt_templates.text_executor_template.format(
        role_instruction=config.roles.text_executor_role,
        text_plan_json=json.dumps(planner_output.text_plan or {}, ensure_ascii=False, indent=2),
        text_generation_prompt=planner_output.text_generation_prompt,
    )


def attach_chinese_translation(text_executor_result: ExecutorResult, config) -> ExecutorResult:
    if text_executor_result.status != "success":
        return text_executor_result

    chinese_translation = ""
    try:
        chinese_translation = run_text_executor_response(
            _build_chinese_translation_prompt(text_executor_result.output_text),
            model=config.models.text_executor_model,
        )
    except Exception as exc:
        text_executor_result.warnings.append(f"Chinese translation unavailable: {exc}")

    draft_bundle = dict(text_executor_result.payload.get("draft_bundle", {}) or {})
    draft_bundle["final_linkedin_drafts"] = text_executor_result.output_text
    draft_bundle["chinese_translation"] = chinese_translation
    text_executor_result.payload["draft_bundle"] = draft_bundle
    return text_executor_result


def run_text_executor(
    planner_output: PlannerOutput,
    config,
    *,
    override_prompt=None,
    include_translation=True,
) -> ExecutorResult:
    prompt = override_prompt or _build_text_executor_prompt(planner_output, config)
    raw_text = run_text_executor_response(prompt, model=config.models.text_executor_model)
    payload = extract_json_payload(raw_text, required_fields=[])
    if "draft_variants" not in payload:
        raise ValueError("draft_variants missing from text executor response")
    draft_variants = _normalize_variant_list(payload["draft_variants"])
    final_drafts = _flatten_variant_text(draft_variants)
    result = ExecutorResult(
        executor_name="text_executor",
        status="success",
        output_text=final_drafts,
        payload={
            "model": config.models.text_executor_model,
            "draft_variants": draft_variants,
            "draft_bundle": {
                "final_linkedin_drafts": final_drafts,
                "chinese_translation": "",
            },
        },
    )
    if include_translation:
        return attach_chinese_translation(result, config)
    return result
