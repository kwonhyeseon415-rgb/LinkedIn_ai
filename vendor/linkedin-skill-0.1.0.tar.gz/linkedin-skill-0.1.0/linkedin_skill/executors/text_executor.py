from linkedin_skill.adapters.openai_client import run_text_executor_response
from linkedin_skill.interfaces.schemas import ExecutorResult, PlannerOutput


def _build_chinese_translation_prompt(english_drafts: str) -> str:
    return (
        "Translate the following LinkedIn drafts into clear, natural Simplified Chinese.\n\n"
        "Rules:\n"
        "- Preserve the original structure, paragraph breaks, separators, bullets, numbering, emojis, hashtags, and calls to action.\n"
        "- Keep the meaning aligned with the English source.\n"
        "- Do not add commentary, explanations, or extra content.\n"
        "- Return only the Chinese translation.\n\n"
        "English LinkedIn drafts:\n"
        f'"""{english_drafts}"""'
    )


def run_text_executor(planner_output: PlannerOutput, config) -> ExecutorResult:
    prompt = config.prompt_templates.text_executor_template.format(
        role_instruction=config.roles.text_executor_role,
        text_generation_prompt=planner_output.text_generation_prompt,
    )
    final_drafts = run_text_executor_response(prompt, model=config.models.text_executor_model)
    chinese_translation = ""
    warnings = []
    try:
        chinese_translation = run_text_executor_response(
            _build_chinese_translation_prompt(final_drafts),
            model=config.models.text_executor_model,
        )
    except Exception as exc:
        warnings.append(f"Chinese translation unavailable: {exc}")

    return ExecutorResult(
        executor_name="text_executor",
        status="success",
        output_text=final_drafts,
        payload={
            "model": config.models.text_executor_model,
            "draft_bundle": {
                "final_linkedin_drafts": final_drafts,
                "chinese_translation": chinese_translation,
            },
        },
        warnings=warnings,
    )
