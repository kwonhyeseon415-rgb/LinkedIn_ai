from linkedin_skill.adapters.openai_client import run_text_executor_response
from linkedin_skill.interfaces.schemas import ExecutorResult, PlannerOutput


def run_text_executor(planner_output: PlannerOutput, config) -> ExecutorResult:
    prompt = config.prompt_templates.text_executor_template.format(
        role_instruction=config.roles.text_executor_role,
        text_generation_prompt=planner_output.text_generation_prompt,
    )
    final_drafts = run_text_executor_response(prompt, model=config.models.text_executor_model)
    return ExecutorResult(
        executor_name="text_executor",
        status="success",
        output_text=final_drafts,
        payload={"model": config.models.text_executor_model},
    )
