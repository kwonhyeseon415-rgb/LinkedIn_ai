from linkedin_skill.interfaces.schemas import ExecutorResult, PlannerOutput


def run_video_executor(planner_output: PlannerOutput, config) -> ExecutorResult:
    return ExecutorResult(
        executor_name="video_executor",
        status="placeholder_not_connected",
        output_text=planner_output.video_generation_prompt,
        payload={
            "model": None,
            "provider_connected": False,
            "placeholder_contract_version": "1.0",
            "artifact_type": "video_generation_prompt",
            "execution_mode": "prompt_only",
            "note": "Video API is not connected in this iteration.",
        },
        warnings=["Video executor is intentionally a placeholder and does not call an external API yet."],
    )
