import json
from pathlib import Path


def load_batch_items(config_path):
    path = Path(config_path)
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, list):
        raise ValueError("Batch config must be a JSON array.")
    if not all(isinstance(item, dict) for item in payload):
        raise ValueError("Each batch config item must be a JSON object.")
    return payload
