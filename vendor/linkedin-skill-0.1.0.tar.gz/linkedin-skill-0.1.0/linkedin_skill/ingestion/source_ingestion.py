from pathlib import Path

from linkedin_skill.interfaces.schemas import SkillRequest
from linkedin_skill.parsing.ocr_channel import run_ocr_extension_slot
from linkedin_skill.parsing.pdf_coordinator import run_pdf_parsing_channels
from linkedin_skill.parsing.text_parsers import parse_pasted_text, parse_txt_file


def ingest_request_sources(request: SkillRequest, config):
    parsed_sources = []

    if request.source_kind == "pasted_text":
        parsed_sources.append(parse_pasted_text(request.pasted_text or ""))
        return {
            "source_label": "粘贴文本",
            "parsed_sources": parsed_sources,
            "ocr_extension": run_ocr_extension_slot(source_kind="pasted_text", config=config),
        }

    source_path = Path(request.source_path).expanduser().resolve()
    if request.source_kind == "txt":
        parsed_sources.append(parse_txt_file(source_path))
        return {
            "source_label": f"TXT 文件｜{source_path.name}",
            "parsed_sources": parsed_sources,
            "ocr_extension": run_ocr_extension_slot(source_kind="txt", config=config),
        }

    return run_pdf_parsing_channels(request=request, source_path=source_path, config=config)
