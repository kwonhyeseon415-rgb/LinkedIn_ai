PROTOCOL_STATUSES = {
    "success",
    "skipped",
    "placeholder_not_connected",
    "failed",
    "partial_success",
}

TOP_LEVEL_RESPONSE_STATUSES = {
    "success",
    "partial_success",
    "failed",
}

SOURCE_KINDS = {
    "pasted_text",
    "txt",
    "pdf",
}

CONTENT_TYPES = {
    "paper",
    "news",
    "case_study",
    "event_update",
}

EXECUTOR_NAMES = {
    "text_executor",
    "image_executor",
    "video_executor",
}

CORE_PIPELINE_STAGES = (
    "source_processing",
    "planner",
    "text_executor",
)

OPTIONAL_CAPABILITY_STAGES = (
    "ocr_extension",
    "image_executor",
    "video_executor",
)

REQUIRED_STAGE_STATUS_KEYS = set(CORE_PIPELINE_STAGES + OPTIONAL_CAPABILITY_STAGES)

PLACEHOLDER_EXECUTOR_MINIMAL_PAYLOAD = {
    "provider_connected",
    "placeholder_contract_version",
    "artifact_type",
    "execution_mode",
}

TEXT_PLAN_REQUIRED_FIELDS = {
    "primary_angle",
    "target_reader_takeaway",
    "must_include_points",
    "tone_instructions",
    "cta_mode",
    "length_target",
    "style_profile_name",
}

OCR_EXTENSION_REQUIRED_FIELDS = {
    "stage",
    "status",
    "enabled",
    "provider_connected",
    "reserved",
    "note",
    "warnings",
    "metadata",
}


def validate_status(value: str) -> str:
    if value not in PROTOCOL_STATUSES:
        raise ValueError(f"Invalid status: {value}")
    return value


def validate_response_status(value: str) -> str:
    if value not in TOP_LEVEL_RESPONSE_STATUSES:
        raise ValueError("response status must be one of: success, partial_success, failed")
    return value


def validate_source_kind(value: str) -> str:
    if value not in SOURCE_KINDS:
        raise ValueError("source_kind must be one of: pasted_text, txt, pdf")
    return value


def validate_content_type(value: str) -> str:
    if value not in CONTENT_TYPES:
        raise ValueError("content_type must be one of: paper, news, case_study, event_update")
    return value


def validate_executor_contract(executor_name: str, status: str, payload: dict):
    if executor_name not in EXECUTOR_NAMES:
        raise ValueError(f"Unsupported executor_name: {executor_name}")
    validate_status(status)
    if status == "placeholder_not_connected":
        missing = PLACEHOLDER_EXECUTOR_MINIMAL_PAYLOAD - set(payload.keys())
        if missing:
            raise ValueError(
                f"{executor_name} placeholder payload missing fields: {', '.join(sorted(missing))}"
            )
        if payload.get("provider_connected") is not False:
            raise ValueError(f"{executor_name} placeholder payload must set provider_connected=False")


def _validate_non_empty_string_list(value, field_name: str):
    if not isinstance(value, list) or not value or not all(
        isinstance(item, str) and item.strip() for item in value
    ):
        raise ValueError(
            f"text_plan.{field_name} must be a non-empty list of non-empty strings"
        )


def validate_text_plan_contract(text_plan):
    if not isinstance(text_plan, dict):
        raise ValueError("text_plan must be a dict")

    missing = TEXT_PLAN_REQUIRED_FIELDS - set(text_plan.keys())
    if missing:
        raise ValueError(f"text_plan missing required fields: {', '.join(sorted(missing))}")

    for field_name in (
        "primary_angle",
        "target_reader_takeaway",
        "cta_mode",
        "length_target",
        "style_profile_name",
    ):
        value = text_plan.get(field_name)
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"text_plan.{field_name} must be a non-empty string")

    _validate_non_empty_string_list(text_plan.get("must_include_points"), "must_include_points")
    _validate_non_empty_string_list(text_plan.get("tone_instructions"), "tone_instructions")


def validate_planner_output_contract(
    status: str,
    highlights_summary: str,
    text_prompt: str,
    text_plan: dict,
    image_prompt: str,
    video_prompt: str,
):
    validate_status(status)
    if status == "success" and not all([highlights_summary, text_prompt, image_prompt, video_prompt]):
        raise ValueError("PlannerOutput fields cannot be empty")
    if status == "success":
        validate_text_plan_contract(text_plan)


def build_default_ocr_extension():
    return {
        "stage": "ocr_extension",
        "status": "skipped",
        "enabled": False,
        "provider_connected": False,
        "reserved": True,
        "note": "OCR extension slot reserved for scanned PDFs.",
        "warnings": [],
        "metadata": {"reason": "not_applicable"},
    }


def validate_ocr_extension_contract(value: dict):
    missing = OCR_EXTENSION_REQUIRED_FIELDS - set(value.keys())
    if missing:
        raise ValueError(f"OCR extension contract missing fields: {', '.join(sorted(missing))}")
    validate_status(value["status"])
    if value["stage"] != "ocr_extension":
        raise ValueError("OCR extension stage must be 'ocr_extension'")


def validate_stage_statuses_contract(stage_statuses: dict):
    missing = REQUIRED_STAGE_STATUS_KEYS - set(stage_statuses.keys())
    if missing:
        raise ValueError(
            f"stage_statuses missing required keys: {', '.join(sorted(missing))}"
        )
    for key, value in stage_statuses.items():
        validate_status(value)


def validate_capability_gaps_contract(value):
    if not isinstance(value, list):
        raise ValueError("capability_gaps must be a list")
    for item in value:
        if not isinstance(item, dict):
            raise ValueError("capability_gaps items must be dict objects")
        missing = {"stage", "status", "note"} - set(item.keys())
        if missing:
            raise ValueError(
                f"capability gap missing fields: {', '.join(sorted(missing))}"
            )
        if item["stage"] not in OPTIONAL_CAPABILITY_STAGES:
            raise ValueError("capability gap stage must be an optional capability stage")
        validate_status(item["status"])


def validate_skill_response_semantics(status: str, core_status: str, stage_statuses: dict):
    validate_response_status(status)
    validate_response_status(core_status)
    validate_stage_statuses_contract(stage_statuses)

    if core_status == "failed" and status != "failed":
        raise ValueError("SkillResponse.status must be failed when core_status is failed")

    if core_status == "partial_success" and status != "partial_success":
        raise ValueError("SkillResponse.status must be partial_success when core_status is partial_success")

    if core_status == "success":
        if status not in {"success", "partial_success"}:
            raise ValueError("SkillResponse.status must be success or partial_success when core_status is success")
        optional_statuses = {stage_statuses[stage] for stage in OPTIONAL_CAPABILITY_STAGES}
        if status == "partial_success" and not (
            "failed" in optional_statuses or "partial_success" in optional_statuses
        ):
            raise ValueError(
                "SkillResponse.status can only be partial_success with core success when an optional stage degraded"
            )
