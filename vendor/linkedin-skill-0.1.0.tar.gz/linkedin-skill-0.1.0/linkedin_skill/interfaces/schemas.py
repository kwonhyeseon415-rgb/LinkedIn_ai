from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional

from linkedin_skill.interfaces.contracts import (
    PROTOCOL_STATUSES,
    build_default_ocr_extension,
    validate_capability_gaps_contract,
    validate_content_type,
    validate_executor_contract,
    validate_ocr_extension_contract,
    validate_planner_output_contract,
    validate_response_status,
    validate_source_kind,
    validate_status,
    validate_skill_response_semantics,
)


EXECUTOR_STATUSES = PROTOCOL_STATUSES


@dataclass
class SkillRequest:
    title: str
    content_type: str
    target_audience: str
    tone: str
    post_count: int
    language: str
    source_kind: str
    pasted_text: Optional[str] = None
    source_path: Optional[str] = None

    def __post_init__(self):
        self.title = (self.title or "").strip()
        self.content_type = (self.content_type or "").strip()
        self.target_audience = (self.target_audience or "").strip()
        self.tone = (self.tone or "").strip()
        self.language = (self.language or "").strip()
        self.source_kind = (self.source_kind or "").strip()
        self.post_count = max(1, int(self.post_count))
        missing_fields = []
        if not self.title:
            missing_fields.append("title")
        if not self.content_type:
            missing_fields.append("content_type")
        if not self.target_audience:
            missing_fields.append("target_audience")
        if not self.tone:
            missing_fields.append("tone")
        if not self.language:
            missing_fields.append("language")
        if missing_fields:
            raise ValueError(f"Missing required SkillRequest fields: {', '.join(missing_fields)}")
        validate_content_type(self.content_type)
        validate_source_kind(self.source_kind)
        if self.source_kind == "pasted_text" and not (self.pasted_text or "").strip():
            raise ValueError("pasted_text source_kind requires pasted_text content")
        if self.source_kind in {"txt", "pdf"} and not (self.source_path or "").strip():
            raise ValueError("txt/pdf source_kind requires source_path")

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ParsedSource:
    channel_name: str
    source_kind: str
    status: str
    text: str
    warnings: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        self.channel_name = (self.channel_name or "").strip()
        self.source_kind = (self.source_kind or "").strip()
        self.status = validate_status(self.status)
        validate_source_kind(self.source_kind)
        self.text = str(self.text or "")
        self.warnings = [str(item) for item in self.warnings]
        self.metadata = dict(self.metadata or {})

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class NormalizedSourcePackage:
    title: str
    content_type: str
    target_audience: str
    tone: str
    post_count: int
    language: str
    source_kind: str
    source_label: str
    normalized_text: str
    parsed_sources: List[ParsedSource]
    status: str
    warnings: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    error_message: Optional[str] = None
    ocr_extension: Dict[str, Any] = field(
        default_factory=build_default_ocr_extension
    )

    def __post_init__(self):
        self.status = validate_status(self.status)
        self.post_count = max(1, int(self.post_count))
        validate_content_type(self.content_type)
        validate_source_kind(self.source_kind)
        self.normalized_text = str(self.normalized_text or "").strip()
        self.parsed_sources = list(self.parsed_sources or [])
        self.warnings = [str(item) for item in self.warnings]
        self.metadata = dict(self.metadata or {})
        self.ocr_extension = dict(self.ocr_extension or {})
        validate_ocr_extension_contract(self.ocr_extension)
        if self.error_message is not None:
            self.error_message = str(self.error_message)
        if self.status != "failed" and not self.normalized_text:
            raise ValueError("NormalizedSourcePackage.normalized_text cannot be empty")

    def to_dict(self) -> Dict[str, Any]:
        payload = asdict(self)
        payload["parsed_sources"] = [item.to_dict() for item in self.parsed_sources]
        return payload


@dataclass
class PlannerOutput:
    highlights_summary: str
    text_generation_prompt: str
    image_generation_prompt: str
    video_generation_prompt: str
    status: str = "success"
    warnings: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    error_message: Optional[str] = None
    text_plan: Optional[Dict[str, Any]] = None

    def __post_init__(self):
        self.status = validate_status(self.status)
        self.highlights_summary = str(self.highlights_summary or "").strip()
        self.text_generation_prompt = str(self.text_generation_prompt or "").strip()
        self.image_generation_prompt = str(self.image_generation_prompt or "").strip()
        self.video_generation_prompt = str(self.video_generation_prompt or "").strip()
        self.warnings = [str(item) for item in self.warnings]
        self.metadata = dict(self.metadata or {})
        if self.error_message is not None:
            self.error_message = str(self.error_message)
        validate_planner_output_contract(
            self.status,
            self.highlights_summary,
            self.text_generation_prompt,
            self.text_plan,
            self.image_generation_prompt,
            self.video_generation_prompt,
        )
        if self.text_plan is not None:
            self.text_plan = dict(self.text_plan)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ExecutorResult:
    executor_name: str
    status: str
    output_text: str = ""
    payload: Dict[str, Any] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)
    error_message: Optional[str] = None

    def __post_init__(self):
        self.status = validate_status(self.status)
        self.executor_name = (self.executor_name or "").strip()
        self.output_text = str(self.output_text or "")
        self.payload = dict(self.payload or {})
        self.warnings = [str(item) for item in self.warnings]
        if self.error_message is not None:
            self.error_message = str(self.error_message)
        validate_executor_contract(self.executor_name, self.status, self.payload)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class SkillResponse:
    request: SkillRequest
    normalized_source: NormalizedSourcePackage
    planner_output: PlannerOutput
    text_executor_result: ExecutorResult
    image_executor_result: ExecutorResult
    video_executor_result: ExecutorResult
    final_linkedin_drafts: str
    status: str
    draft_bundle: Dict[str, Any] = field(default_factory=dict)
    core_status: str = "success"
    stage_statuses: Dict[str, str] = field(default_factory=dict)
    capability_gaps: List[Dict[str, Any]] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    error_message: Optional[str] = None

    def __post_init__(self):
        self.status = validate_response_status(self.status)
        self.core_status = validate_response_status(self.core_status)
        self.final_linkedin_drafts = str(self.final_linkedin_drafts or "")
        resolved_draft_bundle = dict(self.draft_bundle or {})
        resolved_draft_bundle.setdefault("final_linkedin_drafts", self.final_linkedin_drafts)
        resolved_draft_bundle.setdefault("chinese_translation", "")
        self.draft_bundle = {
            "final_linkedin_drafts": str(resolved_draft_bundle.get("final_linkedin_drafts", "") or ""),
            "chinese_translation": str(resolved_draft_bundle.get("chinese_translation", "") or ""),
        }
        self.stage_statuses = dict(self.stage_statuses or {})
        self.capability_gaps = [dict(item) for item in self.capability_gaps]
        validate_capability_gaps_contract(self.capability_gaps)
        self.warnings = [str(item) for item in self.warnings]
        self.metadata = dict(self.metadata or {})
        if self.error_message is not None:
            self.error_message = str(self.error_message)
        validate_skill_response_semantics(
            self.status,
            self.core_status,
            self.stage_statuses,
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "request": self.request.to_dict(),
            "normalized_source": self.normalized_source.to_dict(),
            "planner_output": self.planner_output.to_dict(),
            "text_executor_result": self.text_executor_result.to_dict(),
            "image_executor_result": self.image_executor_result.to_dict(),
            "video_executor_result": self.video_executor_result.to_dict(),
            "final_linkedin_drafts": self.final_linkedin_drafts,
            "draft_bundle": dict(self.draft_bundle),
            "status": self.status,
            "core_status": self.core_status,
            "stage_statuses": dict(self.stage_statuses),
            "capability_gaps": list(self.capability_gaps),
            "warnings": list(self.warnings),
            "metadata": dict(self.metadata),
            "error_message": self.error_message,
        }
