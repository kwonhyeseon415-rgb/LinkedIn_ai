from linkedin_skill.parsing.text_parsers import normalize_source_text


def _is_disabled_channel(parsed_source):
    return (
        parsed_source is not None
        and parsed_source.status == "skipped"
        and parsed_source.metadata.get("reason") == "disabled_by_config"
    )


def _is_successful_channel(parsed_source):
    return parsed_source is not None and parsed_source.status == "success" and parsed_source.text.strip()


def derive_pdf_normalized_text(parsed_sources):
    local_parse = next((item for item in parsed_sources if item.channel_name == "pdf_local_structured_parser"), None)
    llm_parse = next((item for item in parsed_sources if item.channel_name == "pdf_llm_document_understanding"), None)
    warnings = []
    local_success = _is_successful_channel(local_parse)
    llm_success = _is_successful_channel(llm_parse)
    local_disabled = _is_disabled_channel(local_parse)
    llm_disabled = _is_disabled_channel(llm_parse)

    if local_success and llm_success:
        fused_text = "\n\n".join(
            [
                "# PDF LLM Understanding Channel",
                llm_parse.text.strip(),
                "",
                "# PDF Local Structured Parsing Channel",
                local_parse.text.strip(),
            ]
        ).strip()
        return normalize_source_text(fused_text), "success", warnings

    if local_success and llm_disabled:
        warnings.append("PDF LLM understanding channel was disabled by config; normalized source uses the local parser output.")
        return normalize_source_text(local_parse.text), "success", warnings

    if llm_success and local_disabled:
        warnings.append("PDF local structured parser channel was disabled by config; normalized source uses the LLM understanding output.")
        return normalize_source_text(llm_parse.text), "success", warnings

    if local_success:
        warnings.append("PDF dual-channel fusion degraded to local parser output because the LLM channel did not succeed.")
        return normalize_source_text(local_parse.text), "partial_success", warnings

    if llm_success:
        warnings.append("PDF dual-channel fusion degraded to LLM understanding output because the local parser did not succeed.")
        return normalize_source_text(llm_parse.text), "partial_success", warnings

    raise ValueError("PDF parsing failed in both channels.")
