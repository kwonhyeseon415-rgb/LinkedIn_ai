from linkedin_skill.interfaces.contracts import build_default_ocr_extension
from linkedin_skill.interfaces.schemas import NormalizedSourcePackage, SkillRequest
from linkedin_skill.normalization.pdf_fusion import derive_pdf_normalized_text
from linkedin_skill.parsing.text_parsers import normalize_source_text


def _derive_normalized_text(request: SkillRequest, parsed_sources):
    successful = [item for item in parsed_sources if item.status == "success" and item.text.strip()]
    if request.source_kind != "pdf":
        if not successful:
            raise ValueError("No readable source text was produced.")
        return normalize_source_text(successful[0].text), "success", []
    return derive_pdf_normalized_text(parsed_sources)


def normalize_sources(request: SkillRequest, source_label, parsed_sources, ocr_extension=None):
    resolved_ocr_extension = ocr_extension or build_default_ocr_extension()
    normalized_text, status, warnings = _derive_normalized_text(request, parsed_sources)
    combined_warnings = []
    for parsed in parsed_sources:
        combined_warnings.extend(parsed.warnings)
    combined_warnings.extend(warnings)
    combined_warnings.extend(list(resolved_ocr_extension.get("warnings", [])))

    return NormalizedSourcePackage(
        title=request.title,
        content_type=request.content_type,
        target_audience=request.target_audience,
        tone=request.tone,
        post_count=request.post_count,
        language=request.language,
        source_kind=request.source_kind,
        source_label=source_label,
        normalized_text=normalized_text,
        parsed_sources=parsed_sources,
        status=status,
        warnings=combined_warnings,
        metadata={"parsed_channel_count": len(parsed_sources)},
        error_message=None,
        ocr_extension=resolved_ocr_extension,
    )
