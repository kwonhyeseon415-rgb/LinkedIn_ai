from pathlib import Path
from typing import Optional, Protocol


class OCRProviderProtocol(Protocol):
    def extract_text(self, pdf_path: Path) -> str:
        ...


def run_ocr_extension_slot(*, source_kind: str, config, source_path: Optional[Path] = None, provider: Optional[OCRProviderProtocol] = None):
    if source_kind != "pdf":
        return {
            "stage": "ocr_extension",
            "status": "skipped",
            "enabled": False,
            "provider_connected": False,
            "reserved": True,
            "note": "OCR extension is reserved for scanned PDF sources only.",
            "warnings": [],
            "metadata": {"reason": "not_applicable"},
        }

    if not config.feature_flags.enable_ocr_extension:
        return {
            "stage": "ocr_extension",
            "status": "skipped",
            "enabled": False,
            "provider_connected": False,
            "reserved": True,
            "note": "OCR extension disabled by config.",
            "warnings": ["OCR extension disabled by config."],
            "metadata": {"reason": "disabled_by_config"},
        }

    if provider is None:
        return {
            "stage": "ocr_extension",
            "status": "placeholder_not_connected",
            "enabled": True,
            "provider_connected": False,
            "reserved": True,
            "note": "OCR extension enabled, but no OCR provider is connected in this iteration.",
            "warnings": ["OCR extension enabled but no OCR provider is connected."],
            "metadata": {
                "reason": "provider_not_connected",
                "source_path": str(source_path) if source_path else None,
            },
        }

    try:
        extracted_text = provider.extract_text(Path(source_path)) if source_path else ""
        return {
            "stage": "ocr_extension",
            "status": "success",
            "enabled": True,
            "provider_connected": True,
            "reserved": True,
            "note": "OCR provider returned extracted text.",
            "warnings": [],
            "metadata": {
                "reason": "provider_connected",
                "text_preview": extracted_text[:160],
            },
        }
    except Exception as exc:
        return {
            "stage": "ocr_extension",
            "status": "failed",
            "enabled": True,
            "provider_connected": True,
            "reserved": True,
            "note": "OCR provider execution failed.",
            "warnings": [f"OCR provider failed: {exc}"],
            "metadata": {
                "reason": "provider_failure",
                "source_path": str(source_path) if source_path else None,
            },
        }
