import re
import zlib
from pathlib import Path

from linkedin_skill.adapters.openai_client import extract_json_payload, run_pdf_understanding_response
from linkedin_skill.interfaces.schemas import ParsedSource, SkillRequest
from linkedin_skill.parsing.text_parsers import normalize_source_text

try:
    from pypdf import PdfReader
except ImportError:
    PdfReader = None


def decode_pdf_literal_string(raw_text):
    replacements = {
        "n": "\n",
        "r": "\r",
        "t": "\t",
        "b": "\b",
        "f": "\f",
        "\\": "\\",
        "(": "(",
        ")": ")",
    }
    decoded = []
    index = 0
    while index < len(raw_text):
        current = raw_text[index]
        if current != "\\":
            decoded.append(current)
            index += 1
            continue
        index += 1
        if index >= len(raw_text):
            break
        escaped = raw_text[index]
        if escaped in replacements:
            decoded.append(replacements[escaped])
            index += 1
            continue
        if escaped.isdigit():
            octal_digits = escaped
            extra_index = index + 1
            while extra_index < len(raw_text) and len(octal_digits) < 3 and raw_text[extra_index].isdigit():
                octal_digits += raw_text[extra_index]
                extra_index += 1
            decoded.append(chr(int(octal_digits, 8)))
            index = extra_index
            continue
        decoded.append(escaped)
        index += 1
    return "".join(decoded)


def extract_text_fragments_from_pdf_stream(stream_text):
    fragments = []
    for match in re.findall(r"\((?:\\.|[^\\)])*\)\s*Tj", stream_text, re.DOTALL):
        literal = match.rsplit(")", 1)[0][1:]
        fragments.append(decode_pdf_literal_string(literal))
    for group in re.findall(r"\[(.*?)\]\s*TJ", stream_text, re.DOTALL):
        for literal in re.findall(r"\((?:\\.|[^\\)])*\)", group, re.DOTALL):
            fragments.append(decode_pdf_literal_string(literal[1:-1]))
    cleaned = []
    for fragment in fragments:
        normalized = " ".join(fragment.split())
        if normalized:
            cleaned.append(normalized)
    return cleaned


def extract_pdf_text_fallback(pdf_path):
    pdf_bytes = Path(pdf_path).read_bytes()
    stream_chunks = re.findall(rb"stream\r?\n(.*?)\r?\nendstream", pdf_bytes, re.DOTALL)
    extracted = []
    for chunk in stream_chunks:
        candidates = [chunk]
        try:
            candidates.append(zlib.decompress(chunk))
        except Exception:
            pass
        for candidate in candidates:
            decoded = candidate.decode("latin-1", errors="ignore")
            extracted.extend(extract_text_fragments_from_pdf_stream(decoded))
    if not extracted:
        decoded = pdf_bytes.decode("latin-1", errors="ignore")
        extracted.extend(extract_text_fragments_from_pdf_stream(decoded))
    return "\n".join(extracted).strip()


def extract_pdf_text_raw(pdf_path):
    warnings = []
    extracted = ""
    if PdfReader is not None:
        try:
            reader = PdfReader(pdf_path)
            page_texts = [(page.extract_text() or "") for page in reader.pages]
            extracted = normalize_source_text("\n".join(page_texts))
        except Exception as exc:
            warnings.append(f"pypdf parsing failed: {exc}")

    if not extracted:
        try:
            extracted = normalize_source_text(extract_pdf_text_fallback(pdf_path))
        except Exception as exc:
            warnings.append(f"fallback parsing failed: {exc}")

    return extracted, warnings


def flatten_pdf_text_to_markdown(raw_text):
    normalized = normalize_source_text(raw_text)
    if not normalized:
        return ""

    paragraphs = [chunk.strip() for chunk in normalized.split("\n\n") if chunk.strip()]
    lines = ["# Flattened PDF Content"]
    for index, paragraph in enumerate(paragraphs, start=1):
        lines.append("")
        lines.append(f"## Section {index}")
        sentence_like_parts = [part.strip() for part in re.split(r"(?<=[.!?])\s+", paragraph) if part.strip()]
        if len(sentence_like_parts) > 1:
            for part in sentence_like_parts[:6]:
                lines.append(f"- {part}")
        else:
            lines.append(paragraph)
    return "\n".join(lines).strip()


def parse_pdf_locally(pdf_path, raw_text=None, raw_warnings=None):
    warnings = list(raw_warnings or [])
    extracted = normalize_source_text(raw_text or "")
    if not extracted:
        extracted, extraction_warnings = extract_pdf_text_raw(pdf_path)
        warnings.extend(extraction_warnings)

    if extracted:
        flattened_markdown = flatten_pdf_text_to_markdown(extracted)
        return ParsedSource(
            channel_name="pdf_local_structured_parser",
            source_kind="pdf",
            status="success",
            text=flattened_markdown,
            warnings=warnings,
            metadata={"path": str(pdf_path), "format": "markdown_flattened"},
        )

    return ParsedSource(
        channel_name="pdf_local_structured_parser",
        source_kind="pdf",
        status="failed",
        text="",
        warnings=warnings + ["PDF local parsing returned no readable text."],
        metadata={"path": str(pdf_path)},
    )


def build_disabled_channel(channel_name, source_kind, reason):
    return ParsedSource(
        channel_name=channel_name,
        source_kind=source_kind,
        status="skipped",
        text="",
        warnings=[reason],
        metadata={"reason": "disabled_by_config"},
    )


def run_pdf_llm_understanding(request: SkillRequest, raw_pdf_text: str, config):
    if not raw_pdf_text.strip():
        return ParsedSource(
            channel_name="pdf_llm_document_understanding",
            source_kind="pdf",
            status="skipped",
            text="",
            warnings=["Skipped LLM PDF understanding because raw PDF extraction produced no readable text."],
            metadata={"reason": "missing_local_text"},
        )

    prompt = config.prompt_templates.pdf_understanding_template.format(
        role_instruction=config.roles.pdf_understanding_role,
        title=request.title,
        content_type=request.content_type,
        target_audience=request.target_audience,
        tone=request.tone,
        language=request.language,
        source_text=raw_pdf_text[: config.runtime_parameters.pdf_llm_source_char_limit],
    )

    try:
        raw_text = run_pdf_understanding_response(prompt, model=config.models.pdf_llm_model)
        payload = extract_json_payload(
            raw_text,
            required_fields=["document_summary", "key_points", "structured_markdown"],
        )
        llm_text = "\n".join(
            [
                "# Document Summary",
                str(payload["document_summary"]).strip(),
                "",
                "# Key Points",
                *[f"- {item}" for item in payload["key_points"]],
                "",
                "# Structured Markdown",
                str(payload["structured_markdown"]).strip(),
            ]
        ).strip()
        return ParsedSource(
            channel_name="pdf_llm_document_understanding",
            source_kind="pdf",
            status="success",
            text=llm_text,
            warnings=[],
            metadata={"model": config.models.pdf_llm_model},
        )
    except Exception as exc:
        return ParsedSource(
            channel_name="pdf_llm_document_understanding",
            source_kind="pdf",
            status="failed",
            text="",
            warnings=[f"PDF LLM understanding failed: {exc}"],
            metadata={"model": config.models.pdf_llm_model},
        )
