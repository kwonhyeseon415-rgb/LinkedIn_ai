from pathlib import Path

from linkedin_skill.parsing.ocr_channel import run_ocr_extension_slot
from linkedin_skill.parsing.pdf_channels import (
    build_disabled_channel,
    extract_pdf_text_raw,
    parse_pdf_locally,
    run_pdf_llm_understanding,
)


def run_pdf_parsing_channels(request, source_path, config):
    resolved_path = Path(source_path).expanduser().resolve()
    parsed_sources = []
    raw_pdf_text = ""
    raw_pdf_warnings = []
    ocr_extension = run_ocr_extension_slot(
        source_kind="pdf",
        source_path=resolved_path,
        config=config,
    )

    if config.feature_flags.enable_pdf_local_channel or config.feature_flags.enable_pdf_llm_channel:
        raw_pdf_text, raw_pdf_warnings = extract_pdf_text_raw(resolved_path)

    if config.feature_flags.enable_pdf_local_channel:
        parsed_sources.append(
            parse_pdf_locally(
                resolved_path,
                raw_text=raw_pdf_text,
                raw_warnings=raw_pdf_warnings,
            )
        )
    else:
        parsed_sources.append(
            build_disabled_channel(
                channel_name="pdf_local_structured_parser",
                source_kind="pdf",
                reason="Local PDF parsing channel disabled by config.",
            )
        )

    if config.feature_flags.enable_pdf_llm_channel:
        parsed_sources.append(
            run_pdf_llm_understanding(
                request=request,
                raw_pdf_text=raw_pdf_text,
                config=config,
            )
        )
    else:
        parsed_sources.append(
            build_disabled_channel(
                channel_name="pdf_llm_document_understanding",
                source_kind="pdf",
                reason="PDF LLM understanding channel disabled by config.",
            )
        )

    return {
        "source_label": f"PDF 文件｜{resolved_path.name}",
        "parsed_sources": parsed_sources,
        "raw_text_warnings": raw_pdf_warnings,
        "ocr_extension": ocr_extension,
    }
