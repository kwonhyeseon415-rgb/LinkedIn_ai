import re
from pathlib import Path

from linkedin_skill.interfaces.schemas import ParsedSource


def normalize_source_text(text):
    normalized = (text or "").replace("\r\n", "\n").replace("\r", "\n").strip()
    normalized = re.sub(r"[ \t]+\n", "\n", normalized)
    normalized = re.sub(r"\n{3,}", "\n\n", normalized)
    return normalized


def parse_pasted_text(text):
    normalized_text = normalize_source_text(text)
    return ParsedSource(
        channel_name="pasted_text",
        source_kind="pasted_text",
        status="success",
        text=normalized_text,
        warnings=[],
        metadata={"char_count": len(normalized_text)},
    )


def parse_txt_file(path):
    raw_text = Path(path).read_text(encoding="utf-8")
    normalized_text = normalize_source_text(raw_text)
    return ParsedSource(
        channel_name="txt_local_parser",
        source_kind="txt",
        status="success",
        text=normalized_text,
        warnings=[],
        metadata={"path": str(path), "char_count": len(normalized_text)},
    )
