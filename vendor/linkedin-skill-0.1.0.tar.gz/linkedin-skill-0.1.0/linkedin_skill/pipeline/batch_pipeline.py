from pathlib import Path

from linkedin_skill.adapters.python_api import run_linkedin_skill
from linkedin_skill.config import get_default_config
from linkedin_skill.ingestion.batch_configs import load_batch_items
from linkedin_skill.interfaces.schemas import SkillRequest


def infer_source_kind_from_path(path_value):
    suffix = Path(path_value).suffix.lower()
    if suffix == ".txt":
        return "txt"
    if suffix == ".pdf":
        return "pdf"
    raise ValueError(f"不支持的文件类型：{suffix}")


def resolve_project_path(path_value, base_dir):
    path = Path(path_value)
    if path.is_absolute():
        return path
    return Path(base_dir) / path


def build_batch_skill_request(paper, index, base_dir, config=None):
    resolved_config = config or get_default_config()
    title = paper.get("title", f"Record {index}")
    abstract_file = paper.get("abstract_file")
    if not abstract_file:
        raise ValueError("配置缺少 abstract_file")

    resolved_path = str(resolve_project_path(abstract_file, base_dir))
    return SkillRequest(
        title=title,
        content_type=paper.get("content_type", resolved_config.default_content_type),
        target_audience=paper.get("target_audience", ""),
        tone=paper.get("tone", ""),
        post_count=int(paper.get("post_count", 1)),
        language=paper.get("language", "English"),
        source_kind=infer_source_kind_from_path(resolved_path),
        source_path=resolved_path,
    )


def run_batch_skill_checks(config_path, base_dir, config=None):
    resolved_config = config or get_default_config()
    papers = load_batch_items(config_path)
    results = []

    for index, paper in enumerate(papers, start=1):
        platform = paper.get("platform", resolved_config.platform)
        content_type = paper.get("content_type", resolved_config.default_content_type)
        title = paper.get("title", f"Record {index}")
        abstract_file = paper.get("abstract_file")
        target_audience = paper.get("target_audience")
        tone = paper.get("tone")
        post_count = paper.get("post_count")
        language = paper.get("language")

        required_fields = [
            ("abstract_file", abstract_file),
            ("target_audience", target_audience),
            ("tone", tone),
            ("post_count", post_count),
            ("language", language),
        ]
        missing = [field for field, value in required_fields if value in (None, "")]

        if platform != resolved_config.platform:
            results.append(
                {
                    "title": title,
                    "content_type": resolved_config.content_type_labels.get(content_type, content_type),
                    "platform": platform,
                    "status": "Failure",
                    "detail": f"当前 skill shell 仅支持 {resolved_config.platform}。",
                }
            )
            continue

        if missing:
            results.append(
                {
                    "title": title,
                    "content_type": resolved_config.content_type_labels.get(content_type, content_type),
                    "platform": platform,
                    "status": "Failure",
                    "detail": f"配置缺少字段：{', '.join(missing)}",
                }
            )
            continue

        try:
            skill_response = run_linkedin_skill(
                build_batch_skill_request(paper, index, base_dir, resolved_config),
                resolved_config,
            )
            if skill_response.status == "success":
                row_status = "Success"
            elif skill_response.status == "partial_success":
                row_status = "Partial Success"
            else:
                row_status = "Failure"
            results.append(
                {
                    "title": title,
                    "content_type": resolved_config.content_type_labels.get(content_type, content_type),
                    "platform": platform,
                    "status": row_status,
                    "detail": (
                        f"Skill status={skill_response.status}；"
                        f"planner={skill_response.planner_output.status}；"
                        f"text_executor={skill_response.text_executor_result.status}；"
                        f"image_executor={skill_response.image_executor_result.status}；"
                        f"video_executor={skill_response.video_executor_result.status}"
                        + (
                            f"；error={skill_response.error_message}"
                            if getattr(skill_response, "error_message", None)
                            else ""
                        )
                    ),
                }
            )
        except Exception as exc:
            results.append(
                {
                    "title": title,
                    "content_type": resolved_config.content_type_labels.get(content_type, content_type),
                    "platform": platform,
                    "status": "Failure",
                    "detail": f"Skill pipeline 执行失败：{exc}",
                }
            )

    success_count = sum(1 for item in results if item["status"] == "Success")
    partial_count = sum(1 for item in results if item["status"] == "Partial Success")
    failed_count = len(results) - success_count - partial_count
    return {
        "error": None,
        "results": results,
        "total": len(results),
        "success": success_count,
        "partial": partial_count,
        "failed": failed_count,
    }
