from linkedin_skill.interfaces.contracts import (
    CORE_PIPELINE_STAGES,
    OPTIONAL_CAPABILITY_STAGES,
    build_default_ocr_extension,
)
from linkedin_skill.interfaces.schemas import ExecutorResult, NormalizedSourcePackage, PlannerOutput, SkillResponse


def build_failed_normalized_source(request, source_label, parsed_sources, error_message, ocr_extension=None):
    resolved_ocr_extension = ocr_extension or build_default_ocr_extension()
    return NormalizedSourcePackage(
        title=request.title,
        content_type=request.content_type,
        target_audience=request.target_audience,
        tone=request.tone,
        post_count=request.post_count,
        language=request.language,
        source_kind=request.source_kind,
        source_label=source_label,
        normalized_text="",
        parsed_sources=list(parsed_sources or []),
        status="failed",
        warnings=[error_message],
        metadata={"parsed_channel_count": len(parsed_sources or [])},
        error_message=error_message,
        ocr_extension=resolved_ocr_extension,
    )


def build_planner_output(status, error_message=None, warnings=None, metadata=None):
    return PlannerOutput(
        highlights_summary="",
        text_generation_prompt="",
        image_generation_prompt="",
        video_generation_prompt="",
        status=status,
        warnings=list(warnings or []),
        metadata=dict(metadata or {}),
        error_message=error_message,
    )


def build_executor_result(
    executor_name,
    status,
    output_text="",
    payload=None,
    warnings=None,
    error_message=None,
):
    return ExecutorResult(
        executor_name=executor_name,
        status=status,
        output_text=output_text,
        payload=dict(payload or {}),
        warnings=list(warnings or []),
        error_message=error_message,
    )


def build_stage_statuses(normalized_source, planner_output, text_result, image_result, video_result):
    return {
        "source_processing": normalized_source.status,
        "planner": planner_output.status,
        "text_executor": text_result.status,
        "ocr_extension": normalized_source.ocr_extension.get("status", "skipped"),
        "image_executor": image_result.status,
        "video_executor": video_result.status,
    }


def derive_core_status(stage_statuses):
    core_statuses = {stage_statuses[stage] for stage in CORE_PIPELINE_STAGES}
    if "failed" in core_statuses or "skipped" in core_statuses:
        return "failed"
    if "partial_success" in core_statuses:
        return "partial_success"
    return "success"


def derive_overall_status(stage_statuses, core_status):
    if core_status != "success":
        return core_status

    optional_statuses = {stage_statuses[stage] for stage in OPTIONAL_CAPABILITY_STAGES}
    if "failed" in optional_statuses or "partial_success" in optional_statuses:
        return "partial_success"
    return "success"


def build_capability_gaps(normalized_source, image_result, video_result):
    capability_gaps = []
    ocr_extension = normalized_source.ocr_extension or {}
    if ocr_extension.get("status") == "placeholder_not_connected":
        capability_gaps.append(
            {
                "stage": "ocr_extension",
                "status": ocr_extension["status"],
                "note": ocr_extension.get("note", ""),
            }
        )

    for stage_name, executor_result in (
        ("image_executor", image_result),
        ("video_executor", video_result),
    ):
        if executor_result.status == "placeholder_not_connected":
            capability_gaps.append(
                {
                    "stage": stage_name,
                    "status": executor_result.status,
                    "note": executor_result.payload.get("note", ""),
                }
            )
    return capability_gaps


def build_skill_response(
    *,
    request,
    normalized_source,
    planner_output,
    text_executor_result,
    image_executor_result,
    video_executor_result,
    metadata=None,
    error_message=None,
    extra_warnings=None,
):
    stage_statuses = build_stage_statuses(
        normalized_source,
        planner_output,
        text_executor_result,
        image_executor_result,
        video_executor_result,
    )
    warnings = []
    warnings.extend(normalized_source.warnings)
    warnings.extend(planner_output.warnings)
    warnings.extend(text_executor_result.warnings)
    warnings.extend(image_executor_result.warnings)
    warnings.extend(video_executor_result.warnings)
    warnings.extend(list(extra_warnings or []))
    core_status = derive_core_status(stage_statuses)
    capability_gaps = build_capability_gaps(
        normalized_source,
        image_executor_result,
        video_executor_result,
    )
    overall_status = derive_overall_status(stage_statuses, core_status)

    return SkillResponse(
        request=request,
        normalized_source=normalized_source,
        planner_output=planner_output,
        text_executor_result=text_executor_result,
        image_executor_result=image_executor_result,
        video_executor_result=video_executor_result,
        final_linkedin_drafts=text_executor_result.output_text if text_executor_result.status == "success" else "",
        status=overall_status,
        core_status=core_status,
        stage_statuses=stage_statuses,
        capability_gaps=capability_gaps,
        warnings=warnings,
        metadata=dict(metadata or {}),
        error_message=error_message,
    )
