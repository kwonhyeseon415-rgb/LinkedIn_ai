from linkedin_skill.executors import run_image_executor, run_text_executor, run_video_executor
from linkedin_skill.ingestion import ingest_request_sources
from linkedin_skill.normalization import normalize_sources
from linkedin_skill.planner import run_planner
from linkedin_skill.pipeline.response_builders import (
    build_failed_executor_result,
    build_failed_normalized_source,
    build_pipeline_metadata,
    build_planner_output,
    build_skipped_executor_results,
    build_skill_response,
    extract_first_failed_error,
)


def run_skill_pipeline(request, config):
    source_label = {
        "pasted_text": "粘贴文本",
        "txt": "TXT 文件",
        "pdf": "PDF 文件",
    }.get(request.source_kind, "Unknown Source")
    parsed_sources = []
    ocr_extension = None

    try:
        ingestion_result = ingest_request_sources(request, config)
        source_label = ingestion_result["source_label"]
        parsed_sources = ingestion_result["parsed_sources"]
        ocr_extension = ingestion_result.get("ocr_extension")
        normalized_source = normalize_sources(
            request=request,
            source_label=source_label,
            parsed_sources=parsed_sources,
            ocr_extension=ocr_extension,
        )
    except Exception as exc:
        normalized_source = build_failed_normalized_source(
            request=request,
            source_label=source_label,
            parsed_sources=parsed_sources,
            error_message=f"Source processing failed: {exc}",
            ocr_extension=ocr_extension,
        )
        skipped_results = build_skipped_executor_results(
            warning_reason="planner output is unavailable",
            error_message="Planner output unavailable.",
        )
        planner_output = build_planner_output(
            status="skipped",
            error_message="Planner skipped because source processing failed.",
            warnings=["Planner was not executed because source processing did not complete successfully."],
        )
        return build_skill_response(
            request=request,
            normalized_source=normalized_source,
            planner_output=planner_output,
            text_executor_result=skipped_results["text_executor"],
            image_executor_result=skipped_results["image_executor"],
            video_executor_result=skipped_results["video_executor"],
            metadata=build_pipeline_metadata(
                source_label=source_label,
                parsed_sources=parsed_sources,
                failed_stage="source_processing",
            ),
            error_message=str(exc),
        )

    try:
        planner_output = run_planner(normalized_source, config)
    except Exception as exc:
        skipped_results = build_skipped_executor_results(
            warning_reason="planner failed",
            error_message="Planner failed.",
        )
        planner_output = build_planner_output(
            status="failed",
            error_message=f"Planner failed: {exc}",
            warnings=[f"Planner stage failed: {exc}"],
        )
        return build_skill_response(
            request=request,
            normalized_source=normalized_source,
            planner_output=planner_output,
            text_executor_result=skipped_results["text_executor"],
            image_executor_result=skipped_results["image_executor"],
            video_executor_result=skipped_results["video_executor"],
            metadata=build_pipeline_metadata(
                source_label=source_label,
                parsed_sources=parsed_sources,
                failed_stage="planner",
            ),
            error_message=str(exc),
        )

    try:
        text_executor_result = run_text_executor(planner_output, config)
    except Exception as exc:
        text_executor_result = build_failed_executor_result(
            "text_executor",
            exc,
            warning_prefix="Text executor failed",
        )

    try:
        image_executor_result = run_image_executor(planner_output, config)
    except Exception as exc:
        image_executor_result = build_failed_executor_result(
            "image_executor",
            exc,
            warning_prefix="Image executor failed unexpectedly",
        )

    try:
        video_executor_result = run_video_executor(planner_output, config)
    except Exception as exc:
        video_executor_result = build_failed_executor_result(
            "video_executor",
            exc,
            warning_prefix="Video executor failed unexpectedly",
        )

    pipeline_error = extract_first_failed_error(
        text_executor_result,
        image_executor_result,
        video_executor_result,
    )
    return build_skill_response(
        request=request,
        normalized_source=normalized_source,
        planner_output=planner_output,
        text_executor_result=text_executor_result,
        image_executor_result=image_executor_result,
        video_executor_result=video_executor_result,
        metadata=build_pipeline_metadata(
            source_label=source_label,
            parsed_sources=parsed_sources,
        ),
        error_message=pipeline_error,
    )
