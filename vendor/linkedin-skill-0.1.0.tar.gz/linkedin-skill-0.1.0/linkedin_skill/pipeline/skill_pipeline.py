from linkedin_skill.executors import run_image_executor, run_text_executor, run_video_executor
from linkedin_skill.ingestion import ingest_request_sources
from linkedin_skill.normalization import normalize_sources
from linkedin_skill.planner import run_planner
from linkedin_skill.pipeline.response_builders import (
    build_executor_result,
    build_failed_normalized_source,
    build_planner_output,
    build_skill_response,
)


def run_skill_pipeline(request, config):
    source_label = {
        "pasted_text": "粘贴文本",
        "txt": "TXT 文件",
        "pdf": "PDF 文件",
    }.get(request.source_kind, "Unknown Source")
    parsed_sources = []
    ocr_extension = None

    try:
        ingestion_result = ingest_request_sources(request, config)
        source_label = ingestion_result["source_label"]
        parsed_sources = ingestion_result["parsed_sources"]
        ocr_extension = ingestion_result.get("ocr_extension")
        normalized_source = normalize_sources(
            request=request,
            source_label=source_label,
            parsed_sources=parsed_sources,
            ocr_extension=ocr_extension,
        )
    except Exception as exc:
        normalized_source = build_failed_normalized_source(
            request=request,
            source_label=source_label,
            parsed_sources=parsed_sources,
            error_message=f"Source processing failed: {exc}",
            ocr_extension=ocr_extension,
        )
        planner_output = build_planner_output(
            status="skipped",
            error_message="Planner skipped because source processing failed.",
            warnings=["Planner was not executed because source processing did not complete successfully."],
        )
        text_executor_result = build_executor_result(
            executor_name="text_executor",
            status="skipped",
            warnings=["Text executor skipped because planner output is unavailable."],
            error_message="Planner output unavailable.",
        )
        image_executor_result = build_executor_result(
            executor_name="image_executor",
            status="skipped",
            warnings=["Image executor skipped because planner output is unavailable."],
            error_message="Planner output unavailable.",
        )
        video_executor_result = build_executor_result(
            executor_name="video_executor",
            status="skipped",
            warnings=["Video executor skipped because planner output is unavailable."],
            error_message="Planner output unavailable.",
        )
        return build_skill_response(
            request=request,
            normalized_source=normalized_source,
            planner_output=planner_output,
            text_executor_result=text_executor_result,
            image_executor_result=image_executor_result,
            video_executor_result=video_executor_result,
            metadata={"source_label": source_label, "parsed_channel_count": len(parsed_sources), "failed_stage": "source_processing"},
            error_message=str(exc),
        )

    try:
        planner_output = run_planner(normalized_source, config)
    except Exception as exc:
        planner_output = build_planner_output(
            status="failed",
            error_message=f"Planner failed: {exc}",
            warnings=[f"Planner stage failed: {exc}"],
        )
        text_executor_result = build_executor_result(
            executor_name="text_executor",
            status="skipped",
            warnings=["Text executor skipped because planner failed."],
            error_message="Planner failed.",
        )
        image_executor_result = build_executor_result(
            executor_name="image_executor",
            status="skipped",
            warnings=["Image executor skipped because planner failed."],
            error_message="Planner failed.",
        )
        video_executor_result = build_executor_result(
            executor_name="video_executor",
            status="skipped",
            warnings=["Video executor skipped because planner failed."],
            error_message="Planner failed.",
        )
        return build_skill_response(
            request=request,
            normalized_source=normalized_source,
            planner_output=planner_output,
            text_executor_result=text_executor_result,
            image_executor_result=image_executor_result,
            video_executor_result=video_executor_result,
            metadata={"source_label": source_label, "parsed_channel_count": len(parsed_sources), "failed_stage": "planner"},
            error_message=str(exc),
        )

    try:
        text_executor_result = run_text_executor(planner_output, config)
    except Exception as exc:
        text_executor_result = build_executor_result(
            executor_name="text_executor",
            status="failed",
            warnings=[f"Text executor failed: {exc}"],
            error_message=str(exc),
        )

    try:
        image_executor_result = run_image_executor(planner_output, config)
    except Exception as exc:
        image_executor_result = build_executor_result(
            executor_name="image_executor",
            status="failed",
            warnings=[f"Image executor failed unexpectedly: {exc}"],
            error_message=str(exc),
        )

    try:
        video_executor_result = run_video_executor(planner_output, config)
    except Exception as exc:
        video_executor_result = build_executor_result(
            executor_name="video_executor",
            status="failed",
            warnings=[f"Video executor failed unexpectedly: {exc}"],
            error_message=str(exc),
        )

    pipeline_error = None
    for stage_result in (text_executor_result, image_executor_result, video_executor_result):
        if stage_result.status == "failed" and stage_result.error_message:
            pipeline_error = stage_result.error_message
            break
    return build_skill_response(
        request=request,
        normalized_source=normalized_source,
        planner_output=planner_output,
        text_executor_result=text_executor_result,
        image_executor_result=image_executor_result,
        video_executor_result=video_executor_result,
        metadata={
            "source_label": source_label,
            "parsed_channel_count": len(parsed_sources),
        },
        error_message=pipeline_error,
    )
