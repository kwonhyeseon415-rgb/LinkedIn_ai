import json

from linkedin_skill.checkers import run_text_quality_checker
from linkedin_skill.executors import run_image_executor, run_text_executor, run_video_executor
from linkedin_skill.executors.text_executor import attach_chinese_translation
from linkedin_skill.ingestion import ingest_request_sources
from linkedin_skill.normalization import normalize_sources
from linkedin_skill.planner import run_planner
from linkedin_skill.pipeline.response_builders import (
    build_failed_executor_result,
    build_failed_normalized_source,
    build_pipeline_metadata,
    build_planner_output,
    build_skipped_executor_results,
    build_skill_response,
    extract_first_failed_error,
)
from linkedin_skill.style_assets.loader import load_style_profile


def _format_json_for_prompt(value):
    return json.dumps({} if value is None else value, ensure_ascii=False, indent=2)


def _attach_checker_error(text_executor_result, exc):
    text_executor_result.payload["checker_error"] = str(exc)
    text_executor_result.payload.setdefault("rewrite_applied", False)
    text_executor_result.warnings.append(f"Text checker unavailable: {exc}")
    return text_executor_result


def _build_rewrite_prompt(config, *, checker_report, text_plan, draft_variants):
    return config.prompt_templates.rewrite_template.format(
        checker_report=_format_json_for_prompt(checker_report),
        text_plan=_format_json_for_prompt(text_plan),
        draft_variants=_format_json_for_prompt(draft_variants),
    )


def _run_checker(text_executor_result, planner_output, config, style_profile):
    return run_text_quality_checker(
        draft_variants=text_executor_result.payload.get("draft_variants", []),
        text_plan=planner_output.text_plan,
        style_profile=style_profile,
        model=config.models.text_executor_model,
        checker_prompt_template=config.prompt_templates.checker_template,
    )


def _check_and_rewrite_text_result(text_executor_result, planner_output, config):
    if text_executor_result.status != "success":
        return text_executor_result

    try:
        style_profile = load_style_profile(
            explicit_path=config.style_assets.default_style_profile_path or None
        )
        checker_report = _run_checker(text_executor_result, planner_output, config, style_profile)
        text_executor_result.payload["checker_report"] = checker_report
        text_executor_result.payload["rewrite_applied"] = False
    except Exception as exc:
        _attach_checker_error(text_executor_result, exc)
        return attach_chinese_translation(text_executor_result, config)

    if not checker_report.get("rewrite_required"):
        return attach_chinese_translation(text_executor_result, config)

    try:
        rewritten_result = run_text_executor(
            planner_output,
            config,
            override_prompt=_build_rewrite_prompt(
                config,
                checker_report=checker_report,
                text_plan=planner_output.text_plan,
                draft_variants=text_executor_result.payload.get("draft_variants", []),
            ),
            include_translation=False,
        )
    except Exception as exc:
        text_executor_result.payload["rewrite_error"] = str(exc)
        text_executor_result.payload["rewrite_applied"] = False
        text_executor_result.warnings.append(f"Text rewrite unavailable: {exc}")
        return attach_chinese_translation(text_executor_result, config)

    try:
        second_checker_report = _run_checker(rewritten_result, planner_output, config, style_profile)
        rewritten_result.payload["checker_report"] = second_checker_report
        rewritten_result.payload["rewrite_applied"] = True
        return attach_chinese_translation(rewritten_result, config)
    except Exception as exc:
        rewritten_result.payload["checker_error"] = str(exc)
        rewritten_result.payload["rewrite_applied"] = True
        rewritten_result.warnings.append(f"Text checker unavailable after rewrite: {exc}")
        return attach_chinese_translation(rewritten_result, config)


def run_skill_pipeline(request, config):
    source_label = {
        "pasted_text": "粘贴文本",
        "txt": "TXT 文件",
        "pdf": "PDF 文件",
    }.get(request.source_kind, "Unknown Source")
    parsed_sources = []
    ocr_extension = None

    try:
        ingestion_result = ingest_request_sources(request, config)
        source_label = ingestion_result["source_label"]
        parsed_sources = ingestion_result["parsed_sources"]
        ocr_extension = ingestion_result.get("ocr_extension")
        normalized_source = normalize_sources(
            request=request,
            source_label=source_label,
            parsed_sources=parsed_sources,
            ocr_extension=ocr_extension,
        )
    except Exception as exc:
        normalized_source = build_failed_normalized_source(
            request=request,
            source_label=source_label,
            parsed_sources=parsed_sources,
            error_message=f"Source processing failed: {exc}",
            ocr_extension=ocr_extension,
        )
        skipped_results = build_skipped_executor_results(
            warning_reason="planner output is unavailable",
            error_message="Planner output unavailable.",
        )
        planner_output = build_planner_output(
            status="skipped",
            error_message="Planner skipped because source processing failed.",
            warnings=["Planner was not executed because source processing did not complete successfully."],
        )
        return build_skill_response(
            request=request,
            normalized_source=normalized_source,
            planner_output=planner_output,
            text_executor_result=skipped_results["text_executor"],
            image_executor_result=skipped_results["image_executor"],
            video_executor_result=skipped_results["video_executor"],
            metadata=build_pipeline_metadata(
                source_label=source_label,
                parsed_sources=parsed_sources,
                failed_stage="source_processing",
            ),
            error_message=str(exc),
        )

    try:
        planner_output = run_planner(normalized_source, config)
    except Exception as exc:
        skipped_results = build_skipped_executor_results(
            warning_reason="planner failed",
            error_message="Planner failed.",
        )
        planner_output = build_planner_output(
            status="failed",
            error_message=f"Planner failed: {exc}",
            warnings=[f"Planner stage failed: {exc}"],
        )
        return build_skill_response(
            request=request,
            normalized_source=normalized_source,
            planner_output=planner_output,
            text_executor_result=skipped_results["text_executor"],
            image_executor_result=skipped_results["image_executor"],
            video_executor_result=skipped_results["video_executor"],
            metadata=build_pipeline_metadata(
                source_label=source_label,
                parsed_sources=parsed_sources,
                failed_stage="planner",
            ),
            error_message=str(exc),
        )

    try:
        text_executor_result = run_text_executor(
            planner_output,
            config,
            include_translation=False,
        )
        text_executor_result = _check_and_rewrite_text_result(
            text_executor_result,
            planner_output,
            config,
        )
    except Exception as exc:
        text_executor_result = build_failed_executor_result(
            "text_executor",
            exc,
            warning_prefix="Text executor failed",
        )

    try:
        image_executor_result = run_image_executor(planner_output, config)
    except Exception as exc:
        image_executor_result = build_failed_executor_result(
            "image_executor",
            exc,
            warning_prefix="Image executor failed unexpectedly",
        )

    try:
        video_executor_result = run_video_executor(planner_output, config)
    except Exception as exc:
        video_executor_result = build_failed_executor_result(
            "video_executor",
            exc,
            warning_prefix="Video executor failed unexpectedly",
        )

    pipeline_error = extract_first_failed_error(
        text_executor_result,
        image_executor_result,
        video_executor_result,
    )
    return build_skill_response(
        request=request,
        normalized_source=normalized_source,
        planner_output=planner_output,
        text_executor_result=text_executor_result,
        image_executor_result=image_executor_result,
        video_executor_result=video_executor_result,
        metadata=build_pipeline_metadata(
            source_label=source_label,
            parsed_sources=parsed_sources,
        ),
        error_message=pipeline_error,
    )
