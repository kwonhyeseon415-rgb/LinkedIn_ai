import json

from linkedin_skill.adapters.openai_client import extract_json_payload, run_planner_response
from linkedin_skill.interfaces.schemas import NormalizedSourcePackage, PlannerOutput
from linkedin_skill.style_assets.loader import load_style_profile


def run_planner(normalized_source: NormalizedSourcePackage, config) -> PlannerOutput:
    style_profile = load_style_profile(
        explicit_path=config.style_assets.default_style_profile_path or None
    )
    prompt = config.prompt_templates.planner_template.format(
        role_instruction=config.roles.planner_role,
        post_count=normalized_source.post_count,
        language=normalized_source.language,
        style_profile_json=json.dumps(style_profile, ensure_ascii=False, indent=2),
        normalized_text=normalized_source.normalized_text[
            : config.runtime_parameters.planner_source_char_limit
        ],
    )

    raw_text = run_planner_response(prompt, model=config.models.planner_model)
    payload = extract_json_payload(
        raw_text,
        required_fields=[
            "highlights_summary",
            "text_generation_prompt",
            "text_plan",
            "image_generation_prompt",
            "video_generation_prompt",
        ],
    )
    return PlannerOutput(
        highlights_summary=str(payload["highlights_summary"]).strip(),
        text_generation_prompt=str(payload["text_generation_prompt"]).strip(),
        image_generation_prompt=str(payload["image_generation_prompt"]).strip(),
        video_generation_prompt=str(payload["video_generation_prompt"]).strip(),
        status="success",
        metadata={"model": config.models.planner_model},
        text_plan=payload["text_plan"],
    )
