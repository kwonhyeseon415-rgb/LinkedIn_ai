import json
from pathlib import Path
from typing import Any, Dict, Optional, Union

from importlib import resources


DEFAULT_STYLE_PROFILE_FILENAME = "default_style_profile.json"
REQUIRED_STYLE_PROFILE_FIELDS = (
    "profile_name",
    "voice_characteristics",
    "claim_guardrails",
    "preferred_cta_patterns",
    "allowed_patterns",
    "preferred_patterns",
    "disallowed_patterns",
)


def _default_profile_resource():
    return resources.files(__package__).joinpath(DEFAULT_STYLE_PROFILE_FILENAME)


def _read_json_text(explicit_path: Union[str, Path, None]) -> str:
    if explicit_path is None:
        return _default_profile_resource().read_text(encoding="utf-8")
    return Path(explicit_path).read_text(encoding="utf-8")


def _validate_non_empty_string_list(profile: Dict[str, Any], field_name: str) -> None:
    value = profile[field_name]
    if not isinstance(value, list) or not value or not all(isinstance(item, str) and item.strip() for item in value):
        raise ValueError(f"Style profile field '{field_name}' must be a non-empty list of non-empty strings.")


def _validate_style_profile(profile: Any) -> Dict[str, Any]:
    if not isinstance(profile, dict):
        raise ValueError("Style profile must be a JSON object.")

    missing_fields = [field for field in REQUIRED_STYLE_PROFILE_FIELDS if field not in profile]
    if missing_fields:
        raise ValueError(f"Style profile is missing required fields: {', '.join(missing_fields)}")

    profile_name = profile["profile_name"]
    if not isinstance(profile_name, str) or not profile_name.strip():
        raise ValueError("Style profile field 'profile_name' must be a non-empty string.")

    for field in REQUIRED_STYLE_PROFILE_FIELDS[1:]:
        _validate_non_empty_string_list(profile, field)

    return profile


def load_style_profile(*, explicit_path: Optional[Union[str, Path]] = None) -> Dict[str, Any]:
    raw_text = _read_json_text(explicit_path)
    try:
        profile = json.loads(raw_text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Style profile is not valid JSON: {exc}") from exc
    return _validate_style_profile(profile)
