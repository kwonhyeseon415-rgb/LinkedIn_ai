from setuptools import find_packages, setup


setup(
    name="linkedin-skill",
    version="0.1.0",
    description="Skill-first LinkedIn content generation backend with planner, parsing, normalization, and executor pipelines.",
    packages=find_packages(),
    install_requires=[
        "openai",
        "pypdf",
    ],
    entry_points={
        "console_scripts": [
            "linkedin-skill=linkedin_skill.adapters.cli:main",
        ]
    },
)
