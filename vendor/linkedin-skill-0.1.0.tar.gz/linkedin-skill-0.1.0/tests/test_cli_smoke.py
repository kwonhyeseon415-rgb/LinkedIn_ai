import io
import json
import runpy
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch

from linkedin_skill.adapters import cli
from linkedin_skill.interfaces.schemas import SkillRequest


class MockResponse:
    def to_dict(self):
        return {
            "status": "success",
            "final_linkedin_drafts": "Draft",
        }


class CliSmokeTests(unittest.TestCase):
    @patch("linkedin_skill.adapters.cli.run_linkedin_skill", return_value=MockResponse())
    def test_cli_main_builds_request_and_config(self, run_skill_mock):
        argv = [
            "skill-cli",
            "--title",
            "CLI Demo",
            "--content-type",
            "paper",
            "--target-audience",
            "global biotech partners",
            "--tone",
            "professional",
            "--post-count",
            "2",
            "--language",
            "English",
            "--source-kind",
            "pasted_text",
            "--pasted-text",
            "CLI pasted source text",
            "--planner-model",
            "gpt-test-planner",
            "--text-executor-model",
            "gpt-test-executor",
            "--disable-pdf-llm-channel",
        ]

        stdout = io.StringIO()
        with patch("sys.argv", argv), redirect_stdout(stdout):
            cli.main()

        request_arg, config_arg = run_skill_mock.call_args.args
        self.assertIsInstance(request_arg, SkillRequest)
        self.assertEqual(request_arg.title, "CLI Demo")
        self.assertEqual(config_arg.models.planner_model, "gpt-test-planner")
        self.assertEqual(config_arg.models.text_executor_model, "gpt-test-executor")
        self.assertFalse(config_arg.feature_flags.enable_pdf_llm_channel)

        payload = json.loads(stdout.getvalue())
        self.assertEqual(payload["status"], "success")

    @patch("linkedin_skill.adapters.cli.main")
    def test_skill_cli_wrapper_delegates_to_adapter_main(self, main_mock):
        runpy.run_path(
            str(Path(__file__).resolve().parents[1] / "skill_cli.py"),
            run_name="__main__",
        )
        main_mock.assert_called_once_with()


if __name__ == "__main__":
    unittest.main()
