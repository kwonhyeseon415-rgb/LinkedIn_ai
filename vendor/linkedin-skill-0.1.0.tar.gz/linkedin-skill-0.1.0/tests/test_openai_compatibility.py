import os
import unittest
from unittest.mock import patch

from linkedin_skill.adapters import openai_client
from linkedin_skill.config import get_default_config


class OpenAIClientConfigTests(unittest.TestCase):
    @patch("linkedin_skill.adapters.openai_client.OpenAI")
    def test_build_client_uses_api_key_only_when_optional_env_is_absent(self, openai_class):
        with patch.dict(os.environ, {"OPENAI_API_KEY": "sk-test"}, clear=True):
            openai_client._build_client()

        openai_class.assert_called_once_with(api_key="sk-test")

    @patch("linkedin_skill.adapters.openai_client.OpenAI")
    def test_build_client_passes_base_url_and_optional_headers_from_env(self, openai_class):
        with patch.dict(
            os.environ,
            {
                "OPENAI_API_KEY": "sk-test",
                "OPENAI_BASE_URL": "https://openrouter.ai/api/v1",
                "OPENAI_HTTP_REFERER": "https://example.com/demo",
                "OPENAI_APP_TITLE": "LinkedIn Skill Demo",
            },
            clear=True,
        ):
            openai_client._build_client()

        openai_class.assert_called_once_with(
            api_key="sk-test",
            base_url="https://openrouter.ai/api/v1",
            default_headers={
                "HTTP-Referer": "https://example.com/demo",
                "X-OpenRouter-Title": "LinkedIn Skill Demo",
            },
        )

    def test_non_official_base_url_with_bare_model_name_raises_readable_error(self):
        with patch.dict(
            os.environ,
            {
                "OPENAI_API_KEY": "sk-test",
                "OPENAI_BASE_URL": "https://openrouter.ai/api/v1",
            },
            clear=True,
        ):
            with self.assertRaises(openai_client.OpenAIRequestError) as exc:
                openai_client.run_text_response("hello", model="gpt-5.2")

        self.assertIn("provider/model", str(exc.exception))
        self.assertIn("openai/gpt-5.2", str(exc.exception))


class DefaultConfigEnvOverrideTests(unittest.TestCase):
    def test_get_default_config_reads_model_overrides_from_env(self):
        with patch.dict(
            os.environ,
            {
                "PLANNER_MODEL": "openai/gpt-5.2",
                "TEXT_EXECUTOR_MODEL": "openai/gpt-5.2",
                "PDF_LLM_MODEL": "openai/gpt-5.2-mini",
            },
            clear=True,
        ):
            config = get_default_config()

        self.assertEqual(config.models.planner_model, "openai/gpt-5.2")
        self.assertEqual(config.models.text_executor_model, "openai/gpt-5.2")
        self.assertEqual(config.models.pdf_llm_model, "openai/gpt-5.2-mini")

    def test_get_default_config_keeps_existing_model_defaults_without_env_overrides(self):
        with patch.dict(os.environ, {}, clear=True):
            config = get_default_config()

        self.assertEqual(config.models.planner_model, "gpt-5.2")
        self.assertEqual(config.models.text_executor_model, "gpt-5.2")
        self.assertEqual(config.models.pdf_llm_model, "gpt-5.2-mini")


if __name__ == "__main__":
    unittest.main()
