import unittest

from linkedin_skill.interfaces.schemas import (
    ExecutorResult,
    NormalizedSourcePackage,
    ParsedSource,
    PlannerOutput,
    SkillRequest,
    SkillResponse,
)


class SchemaValidationTests(unittest.TestCase):
    def test_skill_request_schema_validation(self):
        with self.assertRaises(ValueError):
            SkillRequest(
                title="",
                content_type="paper",
                target_audience="audience",
                tone="tone",
                post_count=1,
                language="English",
                source_kind="pasted_text",
                pasted_text="hello",
            )

    def test_skill_request_invalid_content_type_validation(self):
        with self.assertRaises(ValueError):
            SkillRequest(
                title="Demo",
                content_type="blog",
                target_audience="audience",
                tone="tone",
                post_count=1,
                language="English",
                source_kind="pasted_text",
                pasted_text="hello",
            )

    def test_planner_output_schema_validation(self):
        with self.assertRaises(ValueError):
            PlannerOutput(
                highlights_summary="",
                text_generation_prompt="text prompt",
                image_generation_prompt="image prompt",
                video_generation_prompt="video prompt",
            )

    def test_executor_status_validation(self):
        with self.assertRaises(ValueError):
            ExecutorResult(
                executor_name="image_executor",
                status="connected",
            )

    def test_executor_placeholder_contract_validation(self):
        with self.assertRaises(ValueError):
            ExecutorResult(
                executor_name="image_executor",
                status="placeholder_not_connected",
                payload={"provider_connected": False},
            )

    def test_normalized_source_schema_validation(self):
        with self.assertRaises(ValueError):
            NormalizedSourcePackage(
                title="Demo",
                content_type="paper",
                target_audience="audience",
                tone="tone",
                post_count=1,
                language="English",
                source_kind="pasted_text",
                source_label="Pasted",
                normalized_text="",
                parsed_sources=[],
                status="success",
            )

    def test_skill_response_schema_validation(self):
        request = SkillRequest(
            title="Demo",
            content_type="paper",
            target_audience="audience",
            tone="tone",
            post_count=1,
            language="English",
            source_kind="pasted_text",
            pasted_text="hello world",
        )
        normalized = NormalizedSourcePackage(
            title="Demo",
            content_type="paper",
            target_audience="audience",
            tone="tone",
            post_count=1,
            language="English",
            source_kind="pasted_text",
            source_label="Pasted",
            normalized_text="hello world",
            parsed_sources=[
                ParsedSource(
                    channel_name="pasted_text_parser",
                    source_kind="pasted_text",
                    status="success",
                    text="hello world",
                )
            ],
            status="success",
        )
        planner = PlannerOutput(
            highlights_summary="Summary",
            text_generation_prompt="Text prompt",
            image_generation_prompt="Image prompt",
            video_generation_prompt="Video prompt",
        )
        text_result = ExecutorResult(executor_name="text_executor", status="success", output_text="Draft")
        image_result = ExecutorResult(
            executor_name="image_executor",
            status="placeholder_not_connected",
            payload={
                "provider_connected": False,
                "placeholder_contract_version": "1.0",
                "artifact_type": "image_generation_prompt",
                "execution_mode": "prompt_only",
            },
        )
        video_result = ExecutorResult(
            executor_name="video_executor",
            status="placeholder_not_connected",
            payload={
                "provider_connected": False,
                "placeholder_contract_version": "1.0",
                "artifact_type": "video_generation_prompt",
                "execution_mode": "prompt_only",
            },
        )
        response = SkillResponse(
            request=request,
            normalized_source=normalized,
            planner_output=planner,
            text_executor_result=text_result,
            image_executor_result=image_result,
            video_executor_result=video_result,
            final_linkedin_drafts="Draft",
            status="success",
            core_status="success",
            stage_statuses={
                "source_processing": "success",
                "planner": "success",
                "text_executor": "success",
                "ocr_extension": "skipped",
                "image_executor": "placeholder_not_connected",
                "video_executor": "placeholder_not_connected",
            },
            capability_gaps=[
                {
                    "stage": "image_executor",
                    "status": "placeholder_not_connected",
                    "note": "Image API is not connected in this iteration.",
                }
            ],
        )
        self.assertEqual(response.to_dict()["status"], "success")

    def test_normalized_source_ocr_contract_validation(self):
        with self.assertRaises(ValueError):
            NormalizedSourcePackage(
                title="Demo",
                content_type="paper",
                target_audience="audience",
                tone="tone",
                post_count=1,
                language="English",
                source_kind="pdf",
                source_label="PDF",
                normalized_text="hello world",
                parsed_sources=[],
                status="success",
                ocr_extension={"status": "skipped"},
            )

    def test_skill_response_requires_stage_status_contract(self):
        request = SkillRequest(
            title="Demo",
            content_type="paper",
            target_audience="audience",
            tone="tone",
            post_count=1,
            language="English",
            source_kind="pasted_text",
            pasted_text="hello world",
        )
        normalized = NormalizedSourcePackage(
            title="Demo",
            content_type="paper",
            target_audience="audience",
            tone="tone",
            post_count=1,
            language="English",
            source_kind="pasted_text",
            source_label="Pasted",
            normalized_text="hello world",
            parsed_sources=[],
            status="success",
        )
        planner = PlannerOutput(
            highlights_summary="Summary",
            text_generation_prompt="Text prompt",
            image_generation_prompt="Image prompt",
            video_generation_prompt="Video prompt",
        )
        text_result = ExecutorResult(executor_name="text_executor", status="success", output_text="Draft")
        image_result = ExecutorResult(
            executor_name="image_executor",
            status="placeholder_not_connected",
            payload={
                "provider_connected": False,
                "placeholder_contract_version": "1.0",
                "artifact_type": "image_generation_prompt",
                "execution_mode": "prompt_only",
            },
        )
        video_result = ExecutorResult(
            executor_name="video_executor",
            status="placeholder_not_connected",
            payload={
                "provider_connected": False,
                "placeholder_contract_version": "1.0",
                "artifact_type": "video_generation_prompt",
                "execution_mode": "prompt_only",
            },
        )
        with self.assertRaises(ValueError):
            SkillResponse(
                request=request,
                normalized_source=normalized,
                planner_output=planner,
                text_executor_result=text_result,
                image_executor_result=image_result,
                video_executor_result=video_result,
                final_linkedin_drafts="Draft",
                status="success",
                core_status="success",
                stage_statuses={"source_processing": "success"},
            )


if __name__ == "__main__":
    unittest.main()
