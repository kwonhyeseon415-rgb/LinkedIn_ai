import json
import tempfile
import unittest
from dataclasses import dataclass
from pathlib import Path
from unittest.mock import patch

from linkedin_skill.adapters.python_api import run_linkedin_skill
from linkedin_skill.config import get_default_config
from linkedin_skill.interfaces.schemas import (
    ExecutorResult,
    NormalizedSourcePackage,
    ParsedSource,
    PlannerOutput,
    SkillRequest,
    SkillResponse,
)
from linkedin_skill.pipeline.batch_pipeline import run_batch_skill_checks


PLANNER_JSON = json.dumps(
    {
        "highlights_summary": "A concise summary of the source material.",
        "text_generation_prompt": "Write exactly 2 final LinkedIn drafts grounded in the source material.",
        "image_generation_prompt": "Create a LinkedIn image prompt grounded in the source material.",
        "video_generation_prompt": "Create a LinkedIn video prompt grounded in the source material.",
    }
)

PDF_JSON = json.dumps(
    {
        "document_summary": "PDF summary",
        "key_points": ["Point A", "Point B"],
        "structured_markdown": "# Section\n- Point A\n- Point B",
    }
)

FINAL_DRAFTS = "Draft 1\nHook...\n\n---\n\nDraft 2\nHook..."
CHINESE_TRANSLATION = "草稿 1\n钩子……\n\n---\n\n草稿 2\n钩子……"


@dataclass
class MockBatchExecutorResult:
    status: str


@dataclass
class MockBatchPlannerOutput:
    status: str


@dataclass
class MockBatchSkillResponse:
    status: str
    planner_output: MockBatchPlannerOutput
    text_executor_result: MockBatchExecutorResult
    image_executor_result: MockBatchExecutorResult
    video_executor_result: MockBatchExecutorResult
    error_message: str = ""


class SkillSmokeTests(unittest.TestCase):
    @patch(
        "linkedin_skill.executors.text_executor.run_text_executor_response",
        side_effect=[FINAL_DRAFTS, CHINESE_TRANSLATION],
    )
    @patch("linkedin_skill.planner.orchestrator.run_planner_response", return_value=PLANNER_JSON)
    def test_pasted_text_smoke(self, _planner_mock, _text_mock):
        request = SkillRequest(
            title="Pasted Text Demo",
            content_type="paper",
            target_audience="global biotech partners",
            tone="professional",
            post_count=2,
            language="English",
            source_kind="pasted_text",
            pasted_text="This is source material for a LinkedIn skill smoke test.",
        )
        response = run_linkedin_skill(request)
        self.assertEqual(response.status, "success")
        self.assertEqual(response.core_status, "success")
        self.assertEqual(response.text_executor_result.status, "success")
        self.assertEqual(response.image_executor_result.status, "placeholder_not_connected")
        self.assertEqual(response.video_executor_result.status, "placeholder_not_connected")
        self.assertEqual(response.stage_statuses["ocr_extension"], "skipped")
        self.assertIn("Draft 1", response.final_linkedin_drafts)
        self.assertEqual(
            response.draft_bundle,
            {
                "final_linkedin_drafts": FINAL_DRAFTS,
                "chinese_translation": CHINESE_TRANSLATION,
            },
        )
        self.assertEqual(response.planner_output.highlights_summary, "A concise summary of the source material.")
        self.assertEqual(
            {item["stage"] for item in response.capability_gaps},
            {"image_executor", "video_executor"},
        )
        self.assertIn("planner_output", response.to_dict())
        self.assertEqual(response.to_dict()["draft_bundle"]["chinese_translation"], CHINESE_TRANSLATION)

    @patch("linkedin_skill.executors.text_executor.run_text_executor_response", return_value=FINAL_DRAFTS)
    @patch("linkedin_skill.planner.orchestrator.run_planner_response", return_value=PLANNER_JSON)
    def test_txt_smoke(self, _planner_mock, _text_mock):
        with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False, encoding="utf-8") as handle:
            handle.write("TXT source material for the LinkedIn skill.")
            txt_path = handle.name

        try:
            request = SkillRequest(
                title="TXT Demo",
                content_type="news",
                target_audience="industry observers",
                tone="insightful",
                post_count=2,
                language="English",
                source_kind="txt",
                source_path=txt_path,
            )
            response = run_linkedin_skill(request)
            self.assertEqual(response.text_executor_result.status, "success")
            self.assertEqual(response.normalized_source.source_kind, "txt")
            self.assertIn("TXT source material", response.normalized_source.normalized_text)
        finally:
            Path(txt_path).unlink(missing_ok=True)

    @patch("linkedin_skill.executors.text_executor.run_text_executor_response", return_value=FINAL_DRAFTS)
    @patch("linkedin_skill.planner.orchestrator.run_planner_response", return_value=PLANNER_JSON)
    @patch(
        "linkedin_skill.parsing.pdf_coordinator.run_pdf_llm_understanding",
        return_value=ParsedSource(
            channel_name="pdf_llm_document_understanding",
            source_kind="pdf",
            status="success",
            text="# Document Summary\nLLM view",
        ),
    )
    @patch(
        "linkedin_skill.parsing.pdf_coordinator.parse_pdf_locally",
        return_value=ParsedSource(
            channel_name="pdf_local_structured_parser",
            source_kind="pdf",
            status="success",
            text="Local parsed PDF text",
        ),
    )
    def test_pdf_smoke(self, _local_mock, _llm_mock, _planner_mock, _text_mock):
        with tempfile.NamedTemporaryFile("wb", suffix=".pdf", delete=False) as handle:
            handle.write(b"%PDF-1.4 test")
            pdf_path = handle.name

        try:
            request = SkillRequest(
                title="PDF Demo",
                content_type="case_study",
                target_audience="potential partners",
                tone="authoritative",
                post_count=2,
                language="English",
                source_kind="pdf",
                source_path=pdf_path,
            )
            response = run_linkedin_skill(request)
            self.assertEqual(response.normalized_source.source_kind, "pdf")
            self.assertEqual(response.normalized_source.status, "success")
            self.assertEqual(response.status, "success")
            self.assertEqual(response.stage_statuses["ocr_extension"], "skipped")
            self.assertIn("PDF LLM Understanding Channel", response.normalized_source.normalized_text)
        finally:
            Path(pdf_path).unlink(missing_ok=True)

    @patch("linkedin_skill.executors.text_executor.run_text_executor_response", return_value=FINAL_DRAFTS)
    @patch("linkedin_skill.planner.orchestrator.run_planner_response", return_value=PLANNER_JSON)
    @patch(
        "linkedin_skill.parsing.pdf_coordinator.run_pdf_llm_understanding",
        return_value=ParsedSource(
            channel_name="pdf_llm_document_understanding",
            source_kind="pdf",
            status="failed",
            text="",
            warnings=["mock llm channel failure"],
        ),
    )
    @patch(
        "linkedin_skill.parsing.pdf_coordinator.parse_pdf_locally",
        return_value=ParsedSource(
            channel_name="pdf_local_structured_parser",
            source_kind="pdf",
            status="success",
            text="Local parsed PDF text",
        ),
    )
    def test_pdf_partial_success_when_llm_channel_fails(self, _local_mock, _llm_mock, _planner_mock, _text_mock):
        with tempfile.NamedTemporaryFile("wb", suffix=".pdf", delete=False) as handle:
            handle.write(b"%PDF-1.4 test")
            pdf_path = handle.name

        try:
            request = SkillRequest(
                title="PDF Partial Demo",
                content_type="event_update",
                target_audience="conference attendees",
                tone="professional",
                post_count=2,
                language="English",
                source_kind="pdf",
                source_path=pdf_path,
            )
            response = run_linkedin_skill(request)
            self.assertEqual(response.normalized_source.status, "partial_success")
            self.assertEqual(response.status, "partial_success")
            self.assertEqual(response.core_status, "partial_success")
            self.assertTrue(any("degraded" in warning for warning in response.warnings))
        finally:
            Path(pdf_path).unlink(missing_ok=True)

    @patch("linkedin_skill.executors.text_executor.run_text_executor_response", return_value=FINAL_DRAFTS)
    @patch("linkedin_skill.planner.orchestrator.run_planner_response", return_value=PLANNER_JSON)
    @patch(
        "linkedin_skill.parsing.pdf_coordinator.run_pdf_llm_understanding",
        return_value=ParsedSource(
            channel_name="pdf_llm_document_understanding",
            source_kind="pdf",
            status="success",
            text="# Document Summary\nLLM only view",
        ),
    )
    def test_pdf_success_when_local_channel_disabled_by_config(self, _llm_mock, _planner_mock, _text_mock):
        with tempfile.NamedTemporaryFile("wb", suffix=".pdf", delete=False) as handle:
            handle.write(b"%PDF-1.4 test")
            pdf_path = handle.name

        try:
            request = SkillRequest(
                title="PDF Config Demo",
                content_type="paper",
                target_audience="biotech partners",
                tone="professional",
                post_count=2,
                language="English",
                source_kind="pdf",
                source_path=pdf_path,
            )
            config = get_default_config()
            config.feature_flags.enable_pdf_local_channel = False
            response = run_linkedin_skill(request, config)
            self.assertEqual(response.normalized_source.status, "success")
            self.assertTrue(
                any("disabled by config" in warning for warning in response.normalized_source.warnings)
            )
        finally:
            Path(pdf_path).unlink(missing_ok=True)

    @patch("linkedin_skill.executors.text_executor.run_text_executor_response", return_value=FINAL_DRAFTS)
    @patch("linkedin_skill.planner.orchestrator.run_planner_response", return_value=PLANNER_JSON)
    @patch(
        "linkedin_skill.parsing.pdf_coordinator.parse_pdf_locally",
        return_value=ParsedSource(
            channel_name="pdf_local_structured_parser",
            source_kind="pdf",
            status="success",
            text="# Flattened PDF Content\n\n## Section 1\n- Local only view",
        ),
    )
    def test_pdf_success_when_llm_channel_disabled_by_config(self, _local_mock, _planner_mock, _text_mock):
        with tempfile.NamedTemporaryFile("wb", suffix=".pdf", delete=False) as handle:
            handle.write(b"%PDF-1.4 test")
            pdf_path = handle.name

        try:
            request = SkillRequest(
                title="PDF Local Demo",
                content_type="paper",
                target_audience="biotech partners",
                tone="professional",
                post_count=2,
                language="English",
                source_kind="pdf",
                source_path=pdf_path,
            )
            config = get_default_config()
            config.feature_flags.enable_pdf_llm_channel = False
            response = run_linkedin_skill(request, config)
            self.assertEqual(response.normalized_source.status, "success")
            self.assertTrue(
                any("disabled by config" in warning for warning in response.normalized_source.warnings)
            )
        finally:
            Path(pdf_path).unlink(missing_ok=True)

    @patch("linkedin_skill.executors.text_executor.run_text_executor_response", return_value=FINAL_DRAFTS)
    @patch("linkedin_skill.planner.orchestrator.run_planner_response", return_value=PLANNER_JSON)
    def test_batch_pipeline_smoke(self, _planner_mock, _text_mock):
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            source_file = temp_path / "source.txt"
            source_file.write_text("Batch source material for the LinkedIn skill.", encoding="utf-8")
            papers_file = temp_path / "papers.json"
            papers_file.write_text(
                json.dumps(
                    [
                        {
                            "platform": "LinkedIn",
                            "title": "Batch Item",
                            "content_type": "paper",
                            "abstract_file": "source.txt",
                            "target_audience": "investors",
                            "tone": "professional",
                            "post_count": 1,
                            "language": "English",
                        }
                    ]
                ),
                encoding="utf-8",
            )

            result = run_batch_skill_checks(str(papers_file), str(temp_path))
            self.assertIsNone(result["error"])
            self.assertEqual(result["success"], 1)
            self.assertEqual(result["partial"], 0)
            self.assertEqual(result["results"][0]["status"], "Success")

    @patch(
        "linkedin_skill.pipeline.batch_pipeline.run_linkedin_skill",
        return_value=MockBatchSkillResponse(
            status="partial_success",
            planner_output=MockBatchPlannerOutput(status="success"),
            text_executor_result=MockBatchExecutorResult(status="success"),
            image_executor_result=MockBatchExecutorResult(status="placeholder_not_connected"),
            video_executor_result=MockBatchExecutorResult(status="placeholder_not_connected"),
        ),
    )
    def test_batch_pipeline_preserves_partial_success(self, _run_skill_mock):
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            source_file = temp_path / "source.txt"
            source_file.write_text("Batch source material for the LinkedIn skill.", encoding="utf-8")
            papers_file = temp_path / "papers.json"
            papers_file.write_text(
                json.dumps(
                    [
                        {
                            "platform": "LinkedIn",
                            "title": "Batch Partial Item",
                            "content_type": "paper",
                            "abstract_file": "source.txt",
                            "target_audience": "investors",
                            "tone": "professional",
                            "post_count": 1,
                            "language": "English",
                        }
                    ]
                ),
                encoding="utf-8",
            )

            result = run_batch_skill_checks(str(papers_file), str(temp_path))
            self.assertEqual(result["partial"], 1)
            self.assertEqual(result["success"], 0)
            self.assertEqual(result["failed"], 0)
            self.assertEqual(result["results"][0]["status"], "Partial Success")

    @patch("linkedin_skill.planner.orchestrator.run_planner_response", side_effect=RuntimeError("planner offline"))
    def test_planner_failure_returns_failed_skill_response(self, _planner_mock):
        request = SkillRequest(
            title="Planner Failure Demo",
            content_type="paper",
            target_audience="global biotech partners",
            tone="professional",
            post_count=2,
            language="English",
            source_kind="pasted_text",
            pasted_text="source material",
        )
        response = run_linkedin_skill(request)
        self.assertEqual(response.status, "failed")
        self.assertEqual(response.planner_output.status, "failed")
        self.assertEqual(response.text_executor_result.status, "skipped")
        self.assertEqual(response.stage_statuses["planner"], "failed")
        self.assertIn("planner offline", response.error_message)
        self.assertEqual(response.final_linkedin_drafts, "")

    @patch("linkedin_skill.executors.text_executor.run_text_executor_response", side_effect=RuntimeError("text executor offline"))
    @patch("linkedin_skill.planner.orchestrator.run_planner_response", return_value=PLANNER_JSON)
    def test_text_executor_failure_returns_failed_skill_response(self, _planner_mock, _text_mock):
        request = SkillRequest(
            title="Text Failure Demo",
            content_type="paper",
            target_audience="global biotech partners",
            tone="professional",
            post_count=2,
            language="English",
            source_kind="pasted_text",
            pasted_text="source material",
        )
        response = run_linkedin_skill(request)
        self.assertEqual(response.status, "failed")
        self.assertEqual(response.planner_output.status, "success")
        self.assertEqual(response.text_executor_result.status, "failed")
        self.assertEqual(response.image_executor_result.status, "placeholder_not_connected")
        self.assertEqual(response.stage_statuses["text_executor"], "failed")
        self.assertIn("text executor offline", response.error_message)

    @patch(
        "linkedin_skill.executors.text_executor.run_text_executor_response",
        side_effect=[FINAL_DRAFTS, RuntimeError("translation offline")],
    )
    @patch("linkedin_skill.planner.orchestrator.run_planner_response", return_value=PLANNER_JSON)
    def test_translation_failure_keeps_english_drafts_and_adds_warning(self, _planner_mock, _text_mock):
        request = SkillRequest(
            title="Translation Failure Demo",
            content_type="paper",
            target_audience="global biotech partners",
            tone="professional",
            post_count=2,
            language="English",
            source_kind="pasted_text",
            pasted_text="source material",
        )
        response = run_linkedin_skill(request)
        self.assertEqual(response.status, "success")
        self.assertEqual(response.core_status, "success")
        self.assertEqual(response.text_executor_result.status, "success")
        self.assertEqual(response.final_linkedin_drafts, FINAL_DRAFTS)
        self.assertEqual(
            response.draft_bundle,
            {
                "final_linkedin_drafts": FINAL_DRAFTS,
                "chinese_translation": "",
            },
        )
        self.assertTrue(any("translation offline" in warning for warning in response.warnings))

    @patch("linkedin_skill.pipeline.skill_pipeline.run_image_executor", side_effect=RuntimeError("image executor crashed"))
    @patch("linkedin_skill.executors.text_executor.run_text_executor_response", return_value=FINAL_DRAFTS)
    @patch("linkedin_skill.planner.orchestrator.run_planner_response", return_value=PLANNER_JSON)
    def test_optional_executor_failure_degrades_overall_without_breaking_core_success(self, _planner_mock, _text_mock, _image_mock):
        request = SkillRequest(
            title="Optional Failure Demo",
            content_type="paper",
            target_audience="global biotech partners",
            tone="professional",
            post_count=2,
            language="English",
            source_kind="pasted_text",
            pasted_text="source material",
        )
        response = run_linkedin_skill(request)
        self.assertEqual(response.core_status, "success")
        self.assertEqual(response.status, "partial_success")
        self.assertEqual(response.text_executor_result.status, "success")
        self.assertEqual(response.image_executor_result.status, "failed")
        self.assertEqual(response.video_executor_result.status, "placeholder_not_connected")
        self.assertEqual(response.stage_statuses["image_executor"], "failed")

    @patch("linkedin_skill.executors.text_executor.run_text_executor_response", return_value=FINAL_DRAFTS)
    @patch("linkedin_skill.planner.orchestrator.run_planner_response", return_value=PLANNER_JSON)
    @patch(
        "linkedin_skill.parsing.pdf_coordinator.run_pdf_llm_understanding",
        return_value=ParsedSource(
            channel_name="pdf_llm_document_understanding",
            source_kind="pdf",
            status="success",
            text="# Document Summary\nLLM view",
        ),
    )
    @patch(
        "linkedin_skill.parsing.pdf_coordinator.parse_pdf_locally",
        return_value=ParsedSource(
            channel_name="pdf_local_structured_parser",
            source_kind="pdf",
            status="success",
            text="Local parsed PDF text",
        ),
    )
    def test_pdf_ocr_disabled_keeps_success_semantics(self, _local_mock, _llm_mock, _planner_mock, _text_mock):
        with tempfile.NamedTemporaryFile("wb", suffix=".pdf", delete=False) as handle:
            handle.write(b"%PDF-1.4 test")
            pdf_path = handle.name

        try:
            request = SkillRequest(
                title="PDF OCR Disabled Demo",
                content_type="paper",
                target_audience="global biotech partners",
                tone="professional",
                post_count=2,
                language="English",
                source_kind="pdf",
                source_path=pdf_path,
            )
            response = run_linkedin_skill(request)
            self.assertEqual(response.status, "success")
            self.assertEqual(response.core_status, "success")
            self.assertEqual(response.stage_statuses["ocr_extension"], "skipped")
            self.assertEqual(response.normalized_source.ocr_extension["status"], "skipped")
            self.assertTrue(any("OCR extension disabled by config." in warning for warning in response.warnings))
        finally:
            Path(pdf_path).unlink(missing_ok=True)

    @patch("linkedin_skill.executors.text_executor.run_text_executor_response", return_value=FINAL_DRAFTS)
    @patch("linkedin_skill.planner.orchestrator.run_planner_response", return_value=PLANNER_JSON)
    @patch(
        "linkedin_skill.parsing.pdf_coordinator.run_pdf_llm_understanding",
        return_value=ParsedSource(
            channel_name="pdf_llm_document_understanding",
            source_kind="pdf",
            status="success",
            text="# Document Summary\nLLM view",
        ),
    )
    @patch(
        "linkedin_skill.parsing.pdf_coordinator.parse_pdf_locally",
        return_value=ParsedSource(
            channel_name="pdf_local_structured_parser",
            source_kind="pdf",
            status="success",
            text="Local parsed PDF text",
        ),
    )
    def test_pdf_ocr_enabled_without_provider_surfaces_placeholder_gap(self, _local_mock, _llm_mock, _planner_mock, _text_mock):
        with tempfile.NamedTemporaryFile("wb", suffix=".pdf", delete=False) as handle:
            handle.write(b"%PDF-1.4 test")
            pdf_path = handle.name

        try:
            request = SkillRequest(
                title="PDF OCR Placeholder Demo",
                content_type="paper",
                target_audience="global biotech partners",
                tone="professional",
                post_count=2,
                language="English",
                source_kind="pdf",
                source_path=pdf_path,
            )
            config = get_default_config()
            config.feature_flags.enable_ocr_extension = True
            response = run_linkedin_skill(request, config)
            self.assertEqual(response.status, "success")
            self.assertEqual(response.core_status, "success")
            self.assertEqual(response.stage_statuses["ocr_extension"], "placeholder_not_connected")
            self.assertEqual(response.normalized_source.ocr_extension["status"], "placeholder_not_connected")
            self.assertIn("ocr_extension", {item["stage"] for item in response.capability_gaps})
            self.assertTrue(any("no OCR provider is connected" in warning for warning in response.warnings))
        finally:
            Path(pdf_path).unlink(missing_ok=True)

    @patch("linkedin_skill.executors.text_executor.run_text_executor_response", return_value=FINAL_DRAFTS)
    @patch("linkedin_skill.planner.orchestrator.run_planner_response", return_value=PLANNER_JSON)
    @patch(
        "linkedin_skill.parsing.pdf_coordinator.run_pdf_llm_understanding",
        return_value=ParsedSource(
            channel_name="pdf_llm_document_understanding",
            source_kind="pdf",
            status="failed",
            text="",
            warnings=["llm channel failed"],
        ),
    )
    @patch(
        "linkedin_skill.parsing.pdf_coordinator.parse_pdf_locally",
        return_value=ParsedSource(
            channel_name="pdf_local_structured_parser",
            source_kind="pdf",
            status="failed",
            text="",
            warnings=["local channel failed"],
        ),
    )
    def test_pdf_both_channels_failed_returns_failed_skill_response(self, _local_mock, _llm_mock, _planner_mock, _text_mock):
        with tempfile.NamedTemporaryFile("wb", suffix=".pdf", delete=False) as handle:
            handle.write(b"%PDF-1.4 test")
            pdf_path = handle.name

        try:
            request = SkillRequest(
                title="PDF Failure Demo",
                content_type="paper",
                target_audience="global biotech partners",
                tone="professional",
                post_count=2,
                language="English",
                source_kind="pdf",
                source_path=pdf_path,
            )
            response = run_linkedin_skill(request)
            self.assertEqual(response.status, "failed")
            self.assertEqual(response.normalized_source.status, "failed")
            self.assertEqual(response.planner_output.status, "skipped")
            self.assertEqual(response.stage_statuses["source_processing"], "failed")
            self.assertIn("PDF parsing failed in both channels", response.error_message)
        finally:
            Path(pdf_path).unlink(missing_ok=True)

    @patch("linkedin_skill.executors.text_executor.run_text_executor_response", return_value=FINAL_DRAFTS)
    @patch("linkedin_skill.planner.orchestrator.run_planner_response", return_value=PLANNER_JSON)
    def test_placeholder_contract_is_explicit(self, _planner_mock, _text_mock):
        request = SkillRequest(
            title="Placeholder Demo",
            content_type="paper",
            target_audience="global biotech partners",
            tone="professional",
            post_count=2,
            language="English",
            source_kind="pasted_text",
            pasted_text="source material",
        )
        response = run_linkedin_skill(request)
        self.assertFalse(response.image_executor_result.payload["provider_connected"])
        self.assertEqual(response.image_executor_result.payload["artifact_type"], "image_generation_prompt")
        self.assertFalse(response.video_executor_result.payload["provider_connected"])
        self.assertEqual(response.video_executor_result.payload["artifact_type"], "video_generation_prompt")


class SchemaValidationTests(unittest.TestCase):
    def test_skill_request_schema_validation(self):
        with self.assertRaises(ValueError):
            SkillRequest(
                title="",
                content_type="paper",
                target_audience="audience",
                tone="tone",
                post_count=1,
                language="English",
                source_kind="pasted_text",
                pasted_text="hello",
            )

    def test_skill_request_invalid_content_type_validation(self):
        with self.assertRaises(ValueError):
            SkillRequest(
                title="Demo",
                content_type="blog",
                target_audience="audience",
                tone="tone",
                post_count=1,
                language="English",
                source_kind="pasted_text",
                pasted_text="hello",
            )

    def test_planner_output_schema_validation(self):
        with self.assertRaises(ValueError):
            PlannerOutput(
                highlights_summary="",
                text_generation_prompt="text prompt",
                image_generation_prompt="image prompt",
                video_generation_prompt="video prompt",
            )

    def test_executor_status_validation(self):
        with self.assertRaises(ValueError):
            ExecutorResult(
                executor_name="image_executor",
                status="connected",
            )

    def test_executor_placeholder_contract_validation(self):
        with self.assertRaises(ValueError):
            ExecutorResult(
                executor_name="image_executor",
                status="placeholder_not_connected",
                payload={"provider_connected": False},
            )

    def test_normalized_source_schema_validation(self):
        with self.assertRaises(ValueError):
            NormalizedSourcePackage(
                title="Demo",
                content_type="paper",
                target_audience="audience",
                tone="tone",
                post_count=1,
                language="English",
                source_kind="pasted_text",
                source_label="Pasted",
                normalized_text="",
                parsed_sources=[],
                status="success",
            )

    def test_skill_response_schema_validation(self):
        request = SkillRequest(
            title="Demo",
            content_type="paper",
            target_audience="audience",
            tone="tone",
            post_count=1,
            language="English",
            source_kind="pasted_text",
            pasted_text="hello world",
        )
        normalized = NormalizedSourcePackage(
            title="Demo",
            content_type="paper",
            target_audience="audience",
            tone="tone",
            post_count=1,
            language="English",
            source_kind="pasted_text",
            source_label="Pasted",
            normalized_text="hello world",
            parsed_sources=[
                ParsedSource(
                    channel_name="pasted_text_parser",
                    source_kind="pasted_text",
                    status="success",
                    text="hello world",
                )
            ],
            status="success",
        )
        planner = PlannerOutput(
            highlights_summary="Summary",
            text_generation_prompt="Text prompt",
            image_generation_prompt="Image prompt",
            video_generation_prompt="Video prompt",
        )
        text_result = ExecutorResult(executor_name="text_executor", status="success", output_text="Draft")
        image_result = ExecutorResult(
            executor_name="image_executor",
            status="placeholder_not_connected",
            payload={
                "provider_connected": False,
                "placeholder_contract_version": "1.0",
                "artifact_type": "image_generation_prompt",
                "execution_mode": "prompt_only",
            },
        )
        video_result = ExecutorResult(
            executor_name="video_executor",
            status="placeholder_not_connected",
            payload={
                "provider_connected": False,
                "placeholder_contract_version": "1.0",
                "artifact_type": "video_generation_prompt",
                "execution_mode": "prompt_only",
            },
        )
        response = SkillResponse(
            request=request,
            normalized_source=normalized,
            planner_output=planner,
            text_executor_result=text_result,
            image_executor_result=image_result,
            video_executor_result=video_result,
            final_linkedin_drafts="Draft",
            status="success",
            core_status="success",
            stage_statuses={
                "source_processing": "success",
                "planner": "success",
                "text_executor": "success",
                "ocr_extension": "skipped",
                "image_executor": "placeholder_not_connected",
                "video_executor": "placeholder_not_connected",
            },
            capability_gaps=[
                {
                    "stage": "image_executor",
                    "status": "placeholder_not_connected",
                    "note": "Image API is not connected in this iteration.",
                }
            ],
        )
        self.assertEqual(response.to_dict()["status"], "success")

    def test_normalized_source_ocr_contract_validation(self):
        with self.assertRaises(ValueError):
            NormalizedSourcePackage(
                title="Demo",
                content_type="paper",
                target_audience="audience",
                tone="tone",
                post_count=1,
                language="English",
                source_kind="pdf",
                source_label="PDF",
                normalized_text="hello world",
                parsed_sources=[],
                status="success",
                ocr_extension={"status": "skipped"},
            )

    def test_skill_response_requires_stage_status_contract(self):
        request = SkillRequest(
            title="Demo",
            content_type="paper",
            target_audience="audience",
            tone="tone",
            post_count=1,
            language="English",
            source_kind="pasted_text",
            pasted_text="hello world",
        )
        normalized = NormalizedSourcePackage(
            title="Demo",
            content_type="paper",
            target_audience="audience",
            tone="tone",
            post_count=1,
            language="English",
            source_kind="pasted_text",
            source_label="Pasted",
            normalized_text="hello world",
            parsed_sources=[],
            status="success",
        )
        planner = PlannerOutput(
            highlights_summary="Summary",
            text_generation_prompt="Text prompt",
            image_generation_prompt="Image prompt",
            video_generation_prompt="Video prompt",
        )
        text_result = ExecutorResult(executor_name="text_executor", status="success", output_text="Draft")
        image_result = ExecutorResult(
            executor_name="image_executor",
            status="placeholder_not_connected",
            payload={
                "provider_connected": False,
                "placeholder_contract_version": "1.0",
                "artifact_type": "image_generation_prompt",
                "execution_mode": "prompt_only",
            },
        )
        video_result = ExecutorResult(
            executor_name="video_executor",
            status="placeholder_not_connected",
            payload={
                "provider_connected": False,
                "placeholder_contract_version": "1.0",
                "artifact_type": "video_generation_prompt",
                "execution_mode": "prompt_only",
            },
        )
        with self.assertRaises(ValueError):
            SkillResponse(
                request=request,
                normalized_source=normalized,
                planner_output=planner,
                text_executor_result=text_result,
                image_executor_result=image_result,
                video_executor_result=video_result,
                final_linkedin_drafts="Draft",
                status="success",
                core_status="success",
                stage_statuses={"source_processing": "success"},
            )


if __name__ == "__main__":
    unittest.main()
