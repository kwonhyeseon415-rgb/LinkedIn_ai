import json
import tempfile
import tarfile
import unittest
import sys
from subprocess import check_output
from pathlib import Path
from tempfile import TemporaryDirectory

from linkedin_skill.style_assets.loader import load_style_profile


class StyleAssetLoadingTests(unittest.TestCase):
    def test_loads_packaged_default_profile(self):
        profile = load_style_profile()

        self.assertEqual(profile["profile_name"], "default_linkedin")
        self.assertIn("voice_characteristics", profile)
        self.assertIn("claim_guardrails", profile)
        self.assertIn("preferred_cta_patterns", profile)
        self.assertIn("allowed_patterns", profile)
        self.assertIn("preferred_patterns", profile)
        self.assertIn("disallowed_patterns", profile)
        self.assertGreater(len(profile["voice_characteristics"]), 0)
        self.assertGreater(len(profile["claim_guardrails"]), 0)
        self.assertGreater(len(profile["preferred_cta_patterns"]), 0)
        self.assertGreater(len(profile["allowed_patterns"]), 0)
        self.assertGreater(len(profile["preferred_patterns"]), 0)
        self.assertGreater(len(profile["disallowed_patterns"]), 0)

    def test_loads_explicit_override_profile(self):
        override_payload = {
            "profile_name": "custom_linkedin",
            "voice_characteristics": ["concise", "professional"],
            "claim_guardrails": ["only claim what is supported"],
            "preferred_cta_patterns": ["Ask a direct question"],
            "allowed_patterns": ["Lead with one clear insight"],
            "preferred_patterns": ["Keep the post concise"],
            "disallowed_patterns": ["Avoid unsupported hype"],
        }

        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False, encoding="utf-8") as handle:
            json.dump(override_payload, handle)
            override_path = Path(handle.name)

        try:
            profile = load_style_profile(explicit_path=override_path)
            self.assertEqual(profile, override_payload)
        finally:
            override_path.unlink(missing_ok=True)

    def test_rejects_missing_required_fields(self):
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False, encoding="utf-8") as handle:
            json.dump(
                {
                    "profile_name": "broken_profile",
                    "voice_characteristics": ["grounded"],
                    "claim_guardrails": ["stay factual"],
                },
                handle,
            )
            profile_path = Path(handle.name)

        try:
            with self.assertRaises(ValueError):
                load_style_profile(explicit_path=profile_path)
        finally:
            profile_path.unlink(missing_ok=True)

    def test_rejects_missing_semantic_sections(self):
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False, encoding="utf-8") as handle:
            json.dump(
                {
                    "profile_name": "broken_profile",
                    "voice_characteristics": ["grounded"],
                    "claim_guardrails": ["stay factual"],
                    "preferred_cta_patterns": ["Ask a question"],
                },
                handle,
            )
            profile_path = Path(handle.name)

        try:
            with self.assertRaises(ValueError):
                load_style_profile(explicit_path=profile_path)
        finally:
            profile_path.unlink(missing_ok=True)

    def test_built_sdist_contains_packaged_default_profile(self):
        repo_root = Path(__file__).resolve().parents[1]

        with TemporaryDirectory() as temp_dir:
            dist_dir = Path(temp_dir)
            check_output(
                [
                    sys.executable,
                    "setup.py",
                    "sdist",
                    "--dist-dir",
                    str(dist_dir),
                ],
                cwd=repo_root,
            )

            sdists = sorted(dist_dir.glob("*.tar.gz"))
            self.assertEqual(len(sdists), 1)

            with tarfile.open(sdists[0], "r:gz") as archive:
                members = archive.getnames()
            self.assertTrue(
                any(member.endswith("linkedin_skill/style_assets/default_style_profile.json") for member in members)
            )


if __name__ == "__main__":
    unittest.main()
